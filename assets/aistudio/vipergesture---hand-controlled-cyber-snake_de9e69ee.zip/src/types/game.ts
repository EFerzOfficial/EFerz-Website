export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export interface Position {
  x: number;
  y: number;
}

export type FoodType = 'standard' | 'golden' | 'freeze' | 'quantum';

export interface FoodItem {
  id: string;
  position: Position;
  type: FoodType;
  expiresAt?: number;
  points: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  decay: number;
}

export type ControlMode = 'finger_point' | 'hand_quadrant' | 'swipe';

export interface GestureDetection {
  direction: Direction | null;
  rawAngle: number | null; // in degrees
  confidence: number;
  isPinching: boolean;
  pinchDistance: number;
  isOpenPalm: boolean;
  isFist: boolean;
  fingerTip: { x: number; y: number } | null;
  wrist: { x: number; y: number } | null;
  landmarksCount: number;
  fps: number;
  engineType: 'mediapipe_ai' | 'instant_optical';
  isSliding: boolean;
  slideVelocity: { vx: number; vy: number; speed: number } | null;
  slideDirection: Direction | null;
}

export interface GameSettings {
  speed: 'relaxed' | 'arcade' | 'hyper';
  wrapAround: boolean;
  soundEnabled: boolean;
  soundVolume: number;
  mirrorCamera: boolean;
  controlMode: ControlMode;
  sensitivity: number; // 0.1 to 1.0 (pointing angle threshold or distance)
  showSkeleton: boolean;
  obstaclesEnabled: boolean;
  theme: 'cyber-cyan' | 'synthwave-magenta' | 'matrix-green' | 'laser-amber';
}

export interface ActivePowerup {
  type: FoodType;
  endTime: number;
  durationMs: number;
}
