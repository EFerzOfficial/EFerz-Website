import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Intercept benign TensorFlow Lite / Emscripten internal stderr info messages
// so they do not trigger false-positive error alerts.
if (typeof window !== 'undefined') {
  const originalError = console.error;
  const originalWarn = console.warn;

  console.error = (...args: unknown[]) => {
    const text = typeof args[0] === 'string' ? args[0] : '';
    if (
      text.includes('Created TensorFlow Lite XNNPACK delegate') ||
      text.startsWith('INFO:') ||
      text.includes('xnnpack')
    ) {
      console.info(...args);
      return;
    }
    originalError.apply(console, args);
  };

  console.warn = (...args: unknown[]) => {
    const text = typeof args[0] === 'string' ? args[0] : '';
    if (
      text.includes('Created TensorFlow Lite XNNPACK delegate') ||
      text.startsWith('INFO:')
    ) {
      console.info(...args);
      return;
    }
    originalWarn.apply(console, args);
  };
}

createRoot(document.getElementById('root')!).render(<App />);
