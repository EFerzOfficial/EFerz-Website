import React, { useCallback, useEffect, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Play,
  RotateCcw,
  Pause,
  Volume2,
  VolumeX,
  Sliders,
  HelpCircle,
  Trophy,
  Zap,
  Activity,
  Flame,
  Hand,
  Shield,
  Sparkles,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
} from 'lucide-react';
import { Direction, GameSettings, GestureDetection } from './types/game';
import { GameEngine } from './utils/gameEngine';
import { sound } from './utils/audio';
import { SnakeCanvas } from './components/SnakeCanvas';
import { WebcamOverlay } from './components/WebcamOverlay';
import { GestureGuideModal } from './components/GestureGuideModal';
import { SettingsModal } from './components/SettingsModal';

const DEFAULT_SETTINGS: GameSettings = {
  speed: 'arcade',
  wrapAround: true,
  soundEnabled: true,
  soundVolume: 0.5,
  mirrorCamera: true,
  controlMode: 'finger_point',
  sensitivity: 0.55,
  showSkeleton: true,
  obstaclesEnabled: false,
  theme: 'cyber-cyan',
};

export default function App() {
  const [engine] = useState<GameEngine>(() => new GameEngine());
  const [settings, setSettings] = useState<GameSettings>(DEFAULT_SETTINGS);

  const [gameState, setGameState] = useState<'idle' | 'playing' | 'paused' | 'gameover'>('idle');
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => engine.highScore);
  const [combo, setCombo] = useState<number>(1);
  const [isBoosting, setIsBoosting] = useState<boolean>(false);
  const [isNewHighScore, setIsNewHighScore] = useState<boolean>(false);
  const [detectedGesture, setDetectedGesture] = useState<GestureDetection | null>(null);

  // Modals
  const [isGuideOpen, setIsGuideOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Debouncing for Palm Pause gesture
  const lastPalmToggleRef = useRef<number>(0);
  // Game Loop interval ref
  const gameLoopTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Sound settings sync
  useEffect(() => {
    sound.setMuted(!settings.soundEnabled);
    sound.setVolume(settings.soundVolume);
  }, [settings.soundEnabled, settings.soundVolume]);

  // Restart / Start Game
  const handleStartGame = useCallback(() => {
    engine.reset(settings);
    setScore(0);
    setHighScore(engine.highScore);
    setCombo(1);
    setIsNewHighScore(false);
    setIsBoosting(false);
    setGameState('playing');
  }, [engine, settings]);

  const handleTogglePause = useCallback(() => {
    setGameState((prev) => (prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev));
  }, []);

  // Gesture handler callback from WebcamOverlay
  const handleGestureDetected = useCallback(
    (detection: GestureDetection) => {
      setDetectedGesture(detection);

      // Handle Open Palm for Pause / Resume
      const now = Date.now();
      if (detection.isOpenPalm && now - lastPalmToggleRef.current > 1200) {
        lastPalmToggleRef.current = now;
        if (gameState === 'playing') {
          setGameState('paused');
          sound.playTurn();
        } else if (gameState === 'paused') {
          setGameState('playing');
          sound.playTurn();
        } else if (gameState === 'gameover' || gameState === 'idle') {
          handleStartGame();
          sound.playTurn();
        }
      }

      // Handle Pinch for Turbo Boost
      if (detection.isPinching !== isBoosting) {
        setIsBoosting(detection.isPinching);
        if (detection.isPinching && gameState === 'playing') {
          sound.playBoostStart();
        }
      }

      // Handle Directional Control if playing
      if (gameState === 'playing' && detection.direction) {
        const changed = engine.setDirection(detection.direction);
        if (changed) {
          sound.playTurn();
        }
      }
    },
    [gameState, isBoosting, engine, handleStartGame]
  );

  // Keyboard navigation fallback
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid scrolling on space/arrows
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === ' ' || e.key === 'Shift') {
        setIsBoosting(true);
        if (gameState === 'playing') sound.playBoostStart();
      }

      if (e.key === 'p' || e.key === 'P') {
        handleTogglePause();
        return;
      }

      if (e.key === 'r' || e.key === 'R') {
        handleStartGame();
        return;
      }

      if (gameState !== 'playing') {
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Enter', ' '].includes(e.key)) {
          handleStartGame();
        }
        return;
      }

      let newDir: Direction | null = null;
      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') newDir = 'UP';
      else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') newDir = 'DOWN';
      else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') newDir = 'LEFT';
      else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') newDir = 'RIGHT';

      if (newDir) {
        const changed = engine.setDirection(newDir);
        if (changed) sound.playTurn();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === ' ' || e.key === 'Shift') {
        setIsBoosting(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState, engine, handleTogglePause, handleStartGame]);

  // Main Game Loop Timer
  useEffect(() => {
    if (gameState !== 'playing') {
      if (gameLoopTimerRef.current) clearTimeout(gameLoopTimerRef.current);
      return;
    }

    // Determine step speed
    let baseMs = 110;
    if (settings.speed === 'relaxed') baseMs = 150;
    else if (settings.speed === 'hyper') baseMs = 75;

    // Powerup modifiers
    if (engine.activePowerup?.type === 'freeze') {
      baseMs = Math.round(baseMs * 1.5);
    }

    // Pinch Turbo modifier
    if (isBoosting) {
      baseMs = Math.max(45, Math.round(baseMs * 0.55));
    }

    const runTick = () => {
      const result = engine.tick(settings, baseMs);
      setScore(engine.score);
      setCombo(engine.combo);

      if (result.ateFood) {
        if (result.ateFood.type === 'golden') {
          sound.playPowerup();
        } else if (result.ateFood.type === 'freeze' || result.ateFood.type === 'quantum') {
          sound.playPowerup();
        } else {
          sound.playEat(engine.combo);
        }
      }

      if (result.gameOver) {
        setGameState('gameover');
        sound.playDie();
        sound.playGameOverJingle();

        if (result.newHighScore) {
          setIsNewHighScore(true);
          setHighScore(engine.score);
          sound.playHighScore();
          try {
            confetti({
              particleCount: 80,
              spread: 70,
              origin: { y: 0.6 },
            });
          } catch {
            // Ignore confetti errors
          }
        }
        return;
      }

      // Schedule next tick
      gameLoopTimerRef.current = setTimeout(runTick, baseMs);
    };

    gameLoopTimerRef.current = setTimeout(runTick, baseMs);

    return () => {
      if (gameLoopTimerRef.current) clearTimeout(gameLoopTimerRef.current);
    };
  }, [gameState, settings, engine, isBoosting]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-slate-950 font-sans">
      {/* Top Navigation & Status Bar */}
      <header className="border-b border-slate-800 bg-slate-900/70 backdrop-blur-md px-4 sm:px-8 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <Activity className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold font-mono tracking-wider text-white flex items-center gap-2">
              VIPER GESTURE
              <span className="text-[10px] font-semibold uppercase tracking-widest text-cyan-400 font-mono px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-800">
                MediaPipe Vision
              </span>
            </h1>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Webcam Hand & Finger Controlled Cyber Snake
            </p>
          </div>
        </div>

        {/* Live Scoreboards */}
        <div className="flex items-center gap-4 sm:gap-6 font-mono">
          <div className="text-right">
            <div className="text-[10px] uppercase text-slate-400 tracking-wider">Score</div>
            <div className="text-lg sm:text-2xl font-bold text-cyan-400 leading-none">
              {score.toString().padStart(4, '0')}
            </div>
          </div>

          <div className="text-right border-l border-slate-800 pl-4 sm:pl-6">
            <div className="text-[10px] uppercase text-slate-400 tracking-wider flex items-center gap-1 justify-end">
              <Trophy className="w-3 h-3 text-amber-400" /> High
            </div>
            <div className="text-lg sm:text-2xl font-bold text-amber-400 leading-none">
              {highScore.toString().padStart(4, '0')}
            </div>
          </div>

          {/* Combo Multiplier Badge */}
          {combo > 1 && (
            <div className="hidden md:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/40 text-amber-400 animate-pulse text-xs font-bold">
              <Flame className="w-3.5 h-3.5 fill-current" />
              {combo}X STREAK
            </div>
          )}

          {/* Toolbar Controls */}
          <div className="flex items-center gap-1 pl-2 sm:pl-4 border-l border-slate-800">
            <button
              onClick={() =>
                setSettings((s) => ({ ...s, soundEnabled: !s.soundEnabled }))
              }
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                settings.soundEnabled
                  ? 'border-slate-700 bg-slate-800 text-slate-300 hover:text-white'
                  : 'border-slate-800 bg-slate-900 text-slate-600'
              }`}
              title={settings.soundEnabled ? 'Mute Audio' : 'Unmute Audio'}
            >
              {settings.soundEnabled ? (
                <Volume2 className="w-4 h-4 text-cyan-400" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={() => setIsGuideOpen(true)}
              className="p-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
              title="Hand Gestures Manual"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
              title="Settings & Hardware"
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Game Arena (Col 1-7) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="relative">
            <SnakeCanvas
              engine={engine}
              settings={settings}
              isPaused={gameState === 'paused'}
              isBoosting={isBoosting}
              detectedDirection={detectedGesture?.direction ?? null}
            />

            {/* In-Game Active Powerups Indicator Banner */}
            {engine.activePowerup && (
              <div className="absolute top-3 left-3 z-10 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/90 border border-cyan-500/50 text-cyan-300 text-xs font-mono shadow-xl backdrop-blur-md">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span className="font-bold uppercase tracking-wider">
                  {engine.activePowerup.type === 'quantum'
                    ? '⚡ Quantum Phase (Pass Walls & Self)'
                    : '❄ Freeze Glitch (Slow-Mo Matrix)'}
                </span>
              </div>
            )}

            {/* Overlay: Game Start / Idle */}
            {gameState === 'idle' && (
              <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center p-6 text-center z-20">
                <div className="w-16 h-16 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center mb-4 text-cyan-400 shadow-xl shadow-cyan-950">
                  <Hand className="w-8 h-8 animate-pulse" />
                </div>
                <h2 className="text-2xl font-bold font-mono text-white mb-2">
                  SLIDE YOUR FINGER TO GLIDE
                </h2>
                <p className="text-sm text-slate-400 max-w-md mb-6 leading-relaxed">
                  In just a finger slide in the air, the snake moves very smoothly with 60 FPS sub-pixel gliding.
                  Pinch fingers for turbo boost or show open palm to pause!
                </p>
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <button
                    onClick={handleStartGame}
                    className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold font-mono rounded-xl shadow-lg shadow-cyan-500/25 flex items-center gap-2 cursor-pointer transition-transform active:scale-95"
                  >
                    <Play className="w-5 h-5 fill-current" /> START CYBER SNAKE
                  </button>
                  <button
                    onClick={() => setIsGuideOpen(true)}
                    className="px-4 py-3 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-mono text-xs rounded-xl flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <HelpCircle className="w-4 h-4" /> Gesture Controls Guide
                  </button>
                </div>
              </div>
            )}

            {/* Overlay: Game Over */}
            {gameState === 'gameover' && (
              <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md rounded-xl flex flex-col items-center justify-center p-6 text-center z-20">
                <div className="p-3 bg-rose-950/60 border border-rose-500/30 rounded-2xl text-rose-400 mb-3">
                  <RotateCcw className="w-8 h-8" />
                </div>
                <h2 className="text-2xl sm:text-3xl font-black font-mono text-white tracking-wider mb-1">
                  SYSTEM OVERLOAD
                </h2>
                <p className="text-xs text-rose-400 font-mono uppercase tracking-widest mb-4">
                  Snake Terminated
                </p>

                {isNewHighScore && (
                  <div className="mb-4 px-4 py-1.5 bg-amber-500/20 border border-amber-500/50 rounded-full text-amber-300 font-mono text-xs font-bold flex items-center gap-2 animate-bounce">
                    <Trophy className="w-4 h-4 text-amber-400 fill-current" />
                    NEW PERSONAL RECORD!
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 w-full max-w-xs mb-6 font-mono">
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-[11px] text-slate-400">FINAL SCORE</div>
                    <div className="text-xl font-bold text-cyan-400">{score}</div>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-[11px] text-slate-400">BEST SCORE</div>
                    <div className="text-xl font-bold text-amber-400">{highScore}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleStartGame}
                    className="px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono rounded-xl shadow-lg shadow-cyan-500/25 flex items-center gap-2 cursor-pointer transition-transform active:scale-95"
                  >
                    <RotateCcw className="w-4 h-4" /> PLAY AGAIN
                  </button>
                  <button
                    onClick={() => setIsSettingsOpen(true)}
                    className="px-4 py-3 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-mono text-xs rounded-xl cursor-pointer"
                  >
                    Adjust Sensitivity
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Action Bar Below Arena */}
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Current Vector:</span>
              <span className="text-cyan-400 font-bold flex items-center gap-1">
                {engine.currentDirection === 'UP' && <ArrowUp className="w-3.5 h-3.5" />}
                {engine.currentDirection === 'DOWN' && <ArrowDown className="w-3.5 h-3.5" />}
                {engine.currentDirection === 'LEFT' && <ArrowLeft className="w-3.5 h-3.5" />}
                {engine.currentDirection === 'RIGHT' && <ArrowRight className="w-3.5 h-3.5" />}
                {engine.currentDirection}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {gameState === 'playing' ? (
                <button
                  onClick={handleTogglePause}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1.5 cursor-pointer"
                >
                  <Pause className="w-3.5 h-3.5" /> Pause [P]
                </button>
              ) : gameState === 'paused' ? (
                <button
                  onClick={handleTogglePause}
                  className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" /> Resume [P]
                </button>
              ) : null}

              <button
                onClick={handleStartGame}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Restart [R]
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Optical Sensor Webcam HUD & Controls (Col 8-12) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {/* Webcam Live Tracker Window */}
          <WebcamOverlay
            settings={settings}
            onGesture={handleGestureDetected}
            currentSnakeDir={engine.currentDirection}
            isBoosting={isBoosting}
          />

          {/* Quick Interactive Gesture Status & Legend */}
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Hand className="w-3.5 h-3.5 text-cyan-400" />
                Gesture Control Matrix
              </span>
              <button
                onClick={() => setIsGuideOpen(true)}
                className="text-[11px] font-mono text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
              >
                Full Guide
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div
                className={`p-2.5 rounded-lg border transition-all ${
                  detectedGesture?.direction
                    ? 'border-cyan-500/50 bg-cyan-950/30 text-cyan-300'
                    : 'border-slate-800 bg-slate-950 text-slate-400'
                }`}
              >
                <div className="text-[10px] text-slate-500 uppercase">Finger Point</div>
                <div className="font-bold mt-0.5">
                  {detectedGesture?.direction ? `👉 ${detectedGesture.direction}` : 'Neutral'}
                </div>
              </div>

              <div
                className={`p-2.5 rounded-lg border transition-all ${
                  isBoosting
                    ? 'border-amber-500/60 bg-amber-950/40 text-amber-300'
                    : 'border-slate-800 bg-slate-950 text-slate-400'
                }`}
              >
                <div className="text-[10px] text-slate-500 uppercase">Pinch Boost</div>
                <div className="font-bold mt-0.5">
                  {isBoosting ? '⚡ ACTIVE (2.2x)' : '👌 Pinch fingers'}
                </div>
              </div>
            </div>

            {/* Special Powerups Legend */}
            <div className="pt-2 border-t border-slate-800/80 flex flex-col gap-1.5">
              <div className="text-[10px] uppercase font-mono tracking-wider text-slate-500">
                Arena Pickups
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block shadow-sm shadow-emerald-400" />
                  <span>Neon Byte (+10)</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block shadow-sm shadow-amber-400" />
                  <span>Golden Core (+50)</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block shadow-sm shadow-cyan-400" />
                  <span>Freeze Glitch (Slow)</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-pink-500 inline-block shadow-sm shadow-pink-500" />
                  <span>Quantum Phase (Ghost)</span>
                </div>
              </div>
            </div>

            {/* Fallback keyboard shortcuts */}
            <div className="text-[11px] text-slate-500 font-mono pt-1">
              Keyboard: <span className="text-slate-400">WASD / Arrow Keys</span> · Boost:{' '}
              <span className="text-slate-400">Spacebar</span> · Pause:{' '}
              <span className="text-slate-400">P</span>
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      <GestureGuideModal isOpen={isGuideOpen} onClose={() => setIsGuideOpen(false)} />
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newVals) => setSettings((s) => ({ ...s, ...newVals }))}
      />
    </div>
  );
}
