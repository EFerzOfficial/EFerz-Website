import { ActivePowerup, Direction, FoodItem, FoodType, GameSettings, Particle, Position } from '../types/game';

export const GRID_SIZE = 26;

export interface Obstacle {
  x: number;
  y: number;
}

export class GameEngine {
  public snake: Position[] = [];
  public currentDirection: Direction = 'RIGHT';
  public nextDirection: Direction = 'RIGHT';
  public foods: FoodItem[] = [];
  public obstacles: Obstacle[] = [];
  public score: number = 0;
  public highScore: number = 0;
  public combo: number = 1;
  public lastEatTime: number = 0;
  public activePowerup: ActivePowerup | null = null;
  public isGameOver: boolean = false;
  public particles: Particle[] = [];
  public prevSnake: Position[] = [];
  public lastTickTime: number = performance.now();
  public tickIntervalMs: number = 100;
  public currentHeadAngle: number = 0;
  public targetHeadAngle: number = 0;

  constructor() {
    this.loadHighScore();
    this.reset();
  }

  public loadHighScore() {
    try {
      const saved = localStorage.getItem('viper_gesture_high_score');
      if (saved) {
        this.highScore = parseInt(saved, 10) || 0;
      }
    } catch {
      // LocalStorage error safe
    }
  }

  public saveHighScore() {
    try {
      if (this.score > this.highScore) {
        this.highScore = this.score;
        localStorage.setItem('viper_gesture_high_score', this.score.toString());
        return true; // new high score achieved!
      }
    } catch {
      // Safe
    }
    return false;
  }

  public reset(settings?: GameSettings) {
    const startX = Math.floor(GRID_SIZE / 2);
    const startY = Math.floor(GRID_SIZE / 2);

    this.snake = [
      { x: startX, y: startY },
      { x: startX - 1, y: startY },
      { x: startX - 2, y: startY },
      { x: startX - 3, y: startY },
    ];
    this.prevSnake = this.snake.map((p) => ({ ...p }));
    this.lastTickTime = performance.now();
    this.currentHeadAngle = 0;
    this.targetHeadAngle = 0;

    this.currentDirection = 'RIGHT';
    this.nextDirection = 'RIGHT';
    this.score = 0;
    this.combo = 1;
    this.lastEatTime = 0;
    this.activePowerup = null;
    this.isGameOver = false;
    this.particles = [];
    this.foods = [];

    // Generate obstacles if enabled
    this.generateObstacles(settings?.obstaclesEnabled ?? false);

    // Spawn first food
    this.spawnFood('standard');
    // Chance to spawn a special bonus
    if (Math.random() > 0.4) {
      this.spawnSpecialFood();
    }
  }

  public generateObstacles(enabled: boolean) {
    this.obstacles = [];
    if (!enabled) return;

    // Symmetrical cyber pylons
    const margin = 4;
    const pylonOffsets = [
      { x: margin, y: margin },
      { x: margin + 1, y: margin },
      { x: margin, y: margin + 1 },

      { x: GRID_SIZE - 1 - margin, y: margin },
      { x: GRID_SIZE - 2 - margin, y: margin },
      { x: GRID_SIZE - 1 - margin, y: margin + 1 },

      { x: margin, y: GRID_SIZE - 1 - margin },
      { x: margin + 1, y: GRID_SIZE - 1 - margin },
      { x: margin, y: GRID_SIZE - 2 - margin },

      { x: GRID_SIZE - 1 - margin, y: GRID_SIZE - 1 - margin },
      { x: GRID_SIZE - 2 - margin, y: GRID_SIZE - 1 - margin },
      { x: GRID_SIZE - 1 - margin, y: GRID_SIZE - 2 - margin },
    ];

    this.obstacles = pylonOffsets;
  }

  public setDirection(newDir: Direction): boolean {
    const opposites: Record<Direction, Direction> = {
      UP: 'DOWN',
      DOWN: 'UP',
      LEFT: 'RIGHT',
      RIGHT: 'LEFT',
    };

    // Prevent direct 180 degree reversal
    if (newDir === opposites[this.currentDirection]) {
      return false;
    }

    if (newDir !== this.currentDirection) {
      this.nextDirection = newDir;
      return true;
    }

    return false;
  }

  public spawnFood(type: FoodType = 'standard'): FoodItem | null {
    const occupied = new Set<string>();
    this.snake.forEach((seg) => occupied.add(`${seg.x},${seg.y}`));
    this.obstacles.forEach((obs) => occupied.add(`${obs.x},${obs.y}`));
    this.foods.forEach((f) => occupied.add(`${f.position.x},${f.position.y}`));

    const available: Position[] = [];
    for (let x = 1; x < GRID_SIZE - 1; x++) {
      for (let y = 1; y < GRID_SIZE - 1; y++) {
        if (!occupied.has(`${x},${y}`)) {
          available.push({ x, y });
        }
      }
    }

    if (available.length === 0) return null;

    const pos = available[Math.floor(Math.random() * available.length)];
    let points = 10;
    let expiresAt: number | undefined = undefined;

    if (type === 'golden') {
      points = 50;
      expiresAt = Date.now() + 10000; // 10 seconds
    } else if (type === 'freeze') {
      points = 25;
      expiresAt = Date.now() + 12000;
    } else if (type === 'quantum') {
      points = 35;
      expiresAt = Date.now() + 8000;
    }

    const item: FoodItem = {
      id: Math.random().toString(36).substring(2, 9),
      position: pos,
      type,
      points,
      expiresAt,
    };

    this.foods.push(item);
    return item;
  }

  public spawnSpecialFood() {
    const types: FoodType[] = ['golden', 'freeze', 'quantum'];
    const selected = types[Math.floor(Math.random() * types.length)];
    this.spawnFood(selected);
  }

  public tick(settings: GameSettings, intervalMs: number = 100): {
    moved: boolean;
    ateFood: FoodItem | null;
    gameOver: boolean;
    newHighScore: boolean;
  } {
    if (this.isGameOver) {
      return { moved: false, ateFood: null, gameOver: true, newHighScore: false };
    }

    // Capture previous positions for smooth 60fps interpolation
    this.prevSnake = this.snake.map((p) => ({ ...p }));
    this.lastTickTime = performance.now();
    this.tickIntervalMs = Math.max(30, intervalMs);

    const now = Date.now();

    // Clean up expired special foods
    this.foods = this.foods.filter((f) => !f.expiresAt || f.expiresAt > now);

    // Clean up expired powerups
    if (this.activePowerup && this.activePowerup.endTime <= now) {
      this.activePowerup = null;
    }

    // Apply queued direction
    this.currentDirection = this.nextDirection;

    // Target head angle
    if (this.currentDirection === 'RIGHT') this.targetHeadAngle = 0;
    else if (this.currentDirection === 'DOWN') this.targetHeadAngle = Math.PI / 2;
    else if (this.currentDirection === 'LEFT') this.targetHeadAngle = Math.PI;
    else if (this.currentDirection === 'UP') this.targetHeadAngle = -Math.PI / 2;

    const head = { ...this.snake[0] };

    switch (this.currentDirection) {
      case 'UP':
        head.y -= 1;
        break;
      case 'DOWN':
        head.y += 1;
        break;
      case 'LEFT':
        head.x -= 1;
        break;
      case 'RIGHT':
        head.x += 1;
        break;
    }

    // Check Wall Collisions
    if (settings.wrapAround) {
      if (head.x < 0) head.x = GRID_SIZE - 1;
      else if (head.x >= GRID_SIZE) head.x = 0;
      if (head.y < 0) head.y = GRID_SIZE - 1;
      else if (head.y >= GRID_SIZE) head.y = 0;
    } else {
      if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
        // Lethal wall hit, unless Quantum Phase is active
        if (!this.activePowerup || this.activePowerup.type !== 'quantum') {
          this.isGameOver = true;
          this.createDeathExplosion(this.snake[0].x, this.snake[0].y);
          const isHigh = this.saveHighScore();
          return { moved: true, ateFood: null, gameOver: true, newHighScore: isHigh };
        } else {
          // Quantum phase wraps around even if wrapAround is off
          if (head.x < 0) head.x = GRID_SIZE - 1;
          else if (head.x >= GRID_SIZE) head.x = 0;
          if (head.y < 0) head.y = GRID_SIZE - 1;
          else if (head.y >= GRID_SIZE) head.y = 0;
        }
      }
    }

    // Check Obstacle Collisions
    const hitObstacle = this.obstacles.some((obs) => obs.x === head.x && obs.y === head.y);
    if (hitObstacle && (!this.activePowerup || this.activePowerup.type !== 'quantum')) {
      this.isGameOver = true;
      this.createDeathExplosion(head.x, head.y);
      const isHigh = this.saveHighScore();
      return { moved: true, ateFood: null, gameOver: true, newHighScore: isHigh };
    }

    // Check Self Collision (ignoring tail tip which will move, unless growing)
    const selfCollision = this.snake.slice(0, -1).some((seg) => seg.x === head.x && seg.y === head.y);
    if (selfCollision && (!this.activePowerup || this.activePowerup.type !== 'quantum')) {
      this.isGameOver = true;
      this.createDeathExplosion(head.x, head.y);
      const isHigh = this.saveHighScore();
      return { moved: true, ateFood: null, gameOver: true, newHighScore: isHigh };
    }

    // Check Food Collection
    const foodIndex = this.foods.findIndex((f) => f.position.x === head.x && f.position.y === head.y);
    let eatenFood: FoodItem | null = null;

    if (foodIndex !== -1) {
      eatenFood = this.foods[foodIndex];
      this.foods.splice(foodIndex, 1);

      // Combo management
      if (now - this.lastEatTime < 4000) {
        this.combo = Math.min(4, this.combo + 1);
      } else {
        this.combo = 1;
      }
      this.lastEatTime = now;

      // Score computation
      const earned = eatenFood.points * this.combo;
      this.score += earned;

      // Handle powerups
      if (eatenFood.type === 'freeze') {
        this.activePowerup = {
          type: 'freeze',
          endTime: now + 7000,
          durationMs: 7000,
        };
      } else if (eatenFood.type === 'quantum') {
        this.activePowerup = {
          type: 'quantum',
          endTime: now + 6000,
          durationMs: 6000,
        };
      }

      // Grow snake (do not pop tail)
      this.snake.unshift(head);

      // Particle explosion
      this.createEatParticles(head.x, head.y, eatenFood.type);

      // Ensure standard food is always present
      const hasStandard = this.foods.some((f) => f.type === 'standard');
      if (!hasStandard) {
        this.spawnFood('standard');
      }

      // Chance to spawn special food
      if (Math.random() < 0.35 && this.foods.length < 3) {
        this.spawnSpecialFood();
      }
    } else {
      // Normal step: add head, pop tail
      this.snake.unshift(head);
      this.snake.pop();
    }

    const isHigh = this.saveHighScore();
    return { moved: true, ateFood: eatenFood, gameOver: false, newHighScore: isHigh };
  }

  public createEatParticles(gx: number, gy: number, type: FoodType) {
    const colors: Record<FoodType, string[]> = {
      standard: ['#4ade80', '#22c55e', '#86efac', '#ffffff'],
      golden: ['#facc15', '#f59e0b', '#fef08a', '#ffffff'],
      freeze: ['#38bdf8', '#0284c7', '#93c5fd', '#ffffff'],
      quantum: ['#ec4899', '#a855f7', '#f472b6', '#ffffff'],
    };

    const palette = colors[type] || colors.standard;

    for (let i = 0; i < 22; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.2 + Math.random() * 3.5;
      this.particles.push({
        x: gx + 0.5,
        y: gy + 0.5,
        vx: Math.cos(angle) * speed * 0.15,
        vy: Math.sin(angle) * speed * 0.15,
        color: palette[Math.floor(Math.random() * palette.length)],
        size: 2.5 + Math.random() * 3,
        alpha: 1,
        decay: 0.035 + Math.random() * 0.04,
      });
    }
  }

  public createDeathExplosion(gx: number, gy: number) {
    for (let i = 0; i < 40; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.5 + Math.random() * 5.0;
      this.particles.push({
        x: gx + 0.5,
        y: gy + 0.5,
        vx: Math.cos(angle) * speed * 0.18,
        vy: Math.sin(angle) * speed * 0.18,
        color: Math.random() > 0.5 ? '#ef4444' : '#f97316',
        size: 3 + Math.random() * 4,
        alpha: 1,
        decay: 0.02 + Math.random() * 0.03,
      });
    }
  }

  public updateParticles() {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= p.decay;
      p.size = Math.max(0.2, p.size * 0.95);
      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  public getInterpolatedPositions(renderTime: number): {
    positions: Array<{ x: number; y: number }>;
    headAngle: number;
  } {
    const elapsed = renderTime - this.lastTickTime;
    const rawT = Math.min(1, Math.max(0, elapsed / this.tickIntervalMs));
    // Linear / ease
    const t = rawT;

    const positions: Array<{ x: number; y: number }> = [];

    for (let i = 0; i < this.snake.length; i++) {
      const curr = this.snake[i];
      const prev = this.prevSnake[i] || curr;

      const dx = curr.x - prev.x;
      const dy = curr.y - prev.y;

      let x: number;
      let y: number;

      if (Math.abs(dx) > 1 || Math.abs(dy) > 1) {
        x = curr.x;
        y = curr.y;
      } else {
        x = prev.x + dx * t;
        y = prev.y + dy * t;
      }

      positions.push({ x, y });
    }

    // Smooth head angle interpolation (shortest arc)
    let diff = this.targetHeadAngle - this.currentHeadAngle;
    while (diff < -Math.PI) diff += Math.PI * 2;
    while (diff > Math.PI) diff -= Math.PI * 2;
    this.currentHeadAngle += diff * 0.28;

    return {
      positions,
      headAngle: this.currentHeadAngle,
    };
  }
}

