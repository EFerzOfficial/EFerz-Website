import { ControlMode, Direction, GestureDetection } from '../types/game';

/**
 * Ultra-fast zero-latency optical tracker.
 * Analyzes video stream directly using offscreen canvas pixel processing (< 1ms per frame).
 * Provides immediate hand steering on frame 0 while MediaPipe AI wasm loads in background.
 */
export class InstantOpticalTracker {
  private offCanvas: HTMLCanvasElement | null = null;
  private offCtx: CanvasRenderingContext2D | null = null;
  private prevCentroid: { x: number; y: number } | null = null;
  private tipHistory: Array<{ x: number; y: number; time: number }> = [];
  private recentDirs: Direction[] = [];
  private lastConfirmedDir: Direction | null = null;
  private fpsCounter: number = 0;
  private lastFpsUpdate: number = performance.now();
  private currentFps: number = 60;

  constructor() {
    if (typeof document !== 'undefined') {
      this.offCanvas = document.createElement('canvas');
      this.offCanvas.width = 160;
      this.offCanvas.height = 120;
      this.offCtx = this.offCanvas.getContext('2d', { willReadFrequently: true });
    }
  }

  public processFrame(
    video: HTMLVideoElement,
    mode: ControlMode = 'finger_point',
    mirror: boolean = true,
    sensitivity: number = 0.5
  ): GestureDetection {
    // FPS tracking
    this.fpsCounter++;
    const now = performance.now();
    if (now - this.lastFpsUpdate >= 1000) {
      this.currentFps = Math.round((this.fpsCounter * 1000) / (now - this.lastFpsUpdate));
      this.fpsCounter = 0;
      this.lastFpsUpdate = now;
    }

    const defaultDetection: GestureDetection = {
      direction: this.lastConfirmedDir,
      rawAngle: null,
      confidence: 0.8,
      isPinching: false,
      pinchDistance: 0.5,
      isOpenPalm: false,
      isFist: false,
      fingerTip: null,
      wrist: null,
      landmarksCount: 0,
      fps: this.currentFps,
      engineType: 'instant_optical',
      isSliding: false,
      slideVelocity: null,
      slideDirection: null,
    };

    if (!this.offCanvas || !this.offCtx || video.readyState < 2) {
      return defaultDetection;
    }

    const w = this.offCanvas.width;
    const h = this.offCanvas.height;

    // Draw downscaled frame
    this.offCtx.drawImage(video, 0, 0, w, h);
    let imgData: ImageData;
    try {
      imgData = this.offCtx.getImageData(0, 0, w, h);
    } catch {
      return defaultDetection;
    }

    const data = imgData.data;

    // Fast skin tone / foreground cluster extraction
    let sumX = 0;
    let sumY = 0;
    let count = 0;
    let minY = h;
    let minX = w;
    let maxX = 0;
    let extremeTipX = 0;
    let extremeTipY = 0;

    // Sample every 2 pixels for extreme speed
    for (let y = 4; y < h - 4; y += 2) {
      for (let x = 4; x < w - 4; x += 2) {
        const idx = (y * w + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];

        // Fast perceptual skin/foreground classifier
        // Standard skin filter: r > 95, g > 40, b > 20, max-min > 15, |r-g| > 15, r > g, r > b
        const isSkin =
          r > 80 &&
          g > 35 &&
          b > 20 &&
          r > g &&
          r > b &&
          r - g > 12 &&
          r - b > 15;

        if (isSkin) {
          sumX += x;
          sumY += y;
          count++;

          if (y < minY) {
            minY = y;
            extremeTipX = x;
            extremeTipY = y;
          }
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
        }
      }
    }

    if (count < 30) {
      // No clear hand detected
      return {
        ...defaultDetection,
        direction: null,
      };
    }

    const centroidX = sumX / count;
    const centroidY = sumY / count;

    // Mirroring adjustment
    const normCentroidX = mirror ? 1 - centroidX / w : centroidX / w;
    const normCentroidY = centroidY / h;
    const normTipX = mirror ? 1 - extremeTipX / w : extremeTipX / w;
    const normTipY = extremeTipY / h;

    let detectedDir: Direction | null = null;
    let rawAngle: number | null = null;

    if (mode === 'finger_point') {
      // Vector from hand centroid to extreme tip
      const dx = normTipX - normCentroidX;
      const dy = normTipY - normCentroidY;
      const mag = Math.hypot(dx, dy);

      const threshold = 0.04 * (1.1 - sensitivity * 0.4);
      if (mag > threshold) {
        const rad = Math.atan2(dy, dx);
        rawAngle = (rad * 180) / Math.PI;

        if (rawAngle >= -45 && rawAngle <= 45) {
          detectedDir = 'RIGHT';
        } else if (rawAngle > 45 && rawAngle < 135) {
          detectedDir = 'DOWN';
        } else if (rawAngle < -45 && rawAngle > -135) {
          detectedDir = 'UP';
        } else {
          detectedDir = 'LEFT';
        }
      }
    } else {
      // Quadrant offset from center
      const offX = normCentroidX - 0.5;
      const offY = normCentroidY - 0.5;
      if (Math.hypot(offX, offY) > 0.1) {
        if (Math.abs(offX) > Math.abs(offY)) {
          detectedDir = offX > 0 ? 'RIGHT' : 'LEFT';
        } else {
          detectedDir = offY > 0 ? 'DOWN' : 'UP';
        }
      }
    }

    // Finger Slide Trajectory & Velocity Tracking
    this.tipHistory.push({ x: normTipX, y: normTipY, time: now });
    while (this.tipHistory.length > 0 && now - this.tipHistory[0].time > 160) {
      this.tipHistory.shift();
    }

    let isSliding = false;
    let slideDirection: Direction | null = null;
    let slideVelocity: { vx: number; vy: number; speed: number } | null = null;

    if (this.tipHistory.length >= 2) {
      const oldest = this.tipHistory[0];
      const deltaX = normTipX - oldest.x;
      const deltaY = normTipY - oldest.y;
      const dt = Math.max(1, now - oldest.time);
      const vx = deltaX / (dt / 1000);
      const vy = deltaY / (dt / 1000);
      const speed = Math.hypot(vx, vy);

      slideVelocity = { vx, vy, speed };

      // Instant finger slide threshold
      if (Math.hypot(deltaX, deltaY) > 0.025 && speed > 0.22) {
        isSliding = true;
        if (Math.abs(deltaX) > Math.abs(deltaY)) {
          slideDirection = deltaX > 0 ? 'RIGHT' : 'LEFT';
        } else {
          slideDirection = deltaY > 0 ? 'DOWN' : 'UP';
        }
      }
    }

    // If user made a finger slide, immediately steer in that direction!
    if (isSliding && slideDirection) {
      detectedDir = slideDirection;
      this.lastConfirmedDir = slideDirection;
    } else if (detectedDir) {
      this.recentDirs.push(detectedDir);
      if (this.recentDirs.length > 3) this.recentDirs.shift();
      const match = this.recentDirs.filter((d) => d === detectedDir).length;
      if (match >= 2) {
        this.lastConfirmedDir = detectedDir;
      }
    }

    // Palm / Pinch estimation from count & bounding box
    const bboxArea = (maxX - minX) * (centroidY - minY);
    const density = count / (bboxArea + 1);
    const isOpenPalm = count > 320 && density < 0.65;
    const isPinching = density > 0.85 && count < 180;

    return {
      direction: this.lastConfirmedDir || detectedDir,
      rawAngle,
      confidence: 0.9,
      isPinching,
      pinchDistance: isPinching ? 0.05 : 0.5,
      isOpenPalm,
      isFist: count > 30 && count < 110,
      fingerTip: { x: normTipX, y: normTipY },
      wrist: { x: normCentroidX, y: normCentroidY },
      landmarksCount: 5,
      fps: this.currentFps,
      engineType: 'instant_optical',
      isSliding,
      slideVelocity,
      slideDirection,
    };
  }
}

export const opticalTracker = new InstantOpticalTracker();
