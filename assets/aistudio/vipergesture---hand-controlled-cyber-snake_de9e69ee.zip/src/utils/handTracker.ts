import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';
import { ControlMode, Direction, GestureDetection } from '../types/game';
import { opticalTracker } from './instantOpticalTracker';

export const HAND_CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4],       // Thumb
  [0, 5], [5, 6], [6, 7], [7, 8],       // Index
  [5, 9], [9, 10], [10, 11], [11, 12],  // Middle
  [9, 13], [13, 14], [14, 15], [15, 16],// Ring
  [13, 17], [17, 18], [18, 19], [19, 20],// Pinky
  [0, 17],                              // Palm base
];

export interface Landmark {
  x: number;
  y: number;
  z?: number;
}

export class HandTrackerService {
  private handLandmarker: HandLandmarker | null = null;
  private isInitializing: boolean = false;
  private isMediaPipeLoaded: boolean = false;
  private initError: string | null = null;
  private lastVideoTime: number = -1;
  private fpsCounter: number = 0;
  private lastFpsUpdate: number = performance.now();
  private currentFps: number = 60;

  // Smoothing buffers and finger slide history
  private tipHistory: Array<{ x: number; y: number; time: number }> = [];
  private recentDirections: Direction[] = [];
  private lastConfirmedDirection: Direction | null = null;

  public async initialize(): Promise<void> {
    if (this.handLandmarker) return;
    if (this.isInitializing) return;

    this.isInitializing = true;
    this.initError = null;

    try {
      // 1. Resolve WASM assets locally first for instant speed, fallback to CDN
      let vision;
      try {
        vision = await FilesetResolver.forVisionTasks('/mediapipe/wasm');
      } catch (localWasmErr) {
        console.warn('Local wasm resolve failed, using CDN fallback:', localWasmErr);
        vision = await FilesetResolver.forVisionTasks(
          'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.18/wasm'
        );
      }

      // 2. Resolve model locally first for instant load, fallback to Google Cloud Storage
      const modelAssetPath = '/mediapipe/models/hand_landmarker.task';

      // Use CPU delegate by default: CPU loads in ~150ms with WebAssembly SIMD,
      // avoiding 10-20 second WebGL shader compilation lag on laptops.
      try {
        this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath,
            delegate: 'CPU',
          },
          runningMode: 'VIDEO',
          numHands: 1,
          minHandDetectionConfidence: 0.45,
          minHandPresenceConfidence: 0.45,
          minTrackingConfidence: 0.45,
        });
        this.isMediaPipeLoaded = true;
      } catch (cpuErr) {
        console.warn('CPU model load failed, attempting with CDN model path:', cpuErr);
        // Fallback to remote CDN path with CPU delegate
        this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath:
              'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
            delegate: 'CPU',
          },
          runningMode: 'VIDEO',
          numHands: 1,
          minHandDetectionConfidence: 0.45,
          minHandPresenceConfidence: 0.45,
          minTrackingConfidence: 0.45,
        });
        this.isMediaPipeLoaded = true;
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      this.initError = `MediaPipe load note: ${message}. Using instant optical fallback.`;
      console.warn(this.initError);
    } finally {
      this.isInitializing = false;
    }
  }

  public isReady(): boolean {
    // Service is immediately ready via dual optical + AI engine
    return true;
  }

  public isAiModelReady(): boolean {
    return this.isMediaPipeLoaded && this.handLandmarker !== null;
  }

  public getError(): string | null {
    return this.initError;
  }

  /**
   * Process a single video frame. If MediaPipe is loaded, runs 21-point neural tracking.
   * If MediaPipe is still initializing or unavailable, instantly runs optical tracking (< 1ms).
   */
  public processVideoFrame(
    video: HTMLVideoElement,
    mode: ControlMode = 'finger_point',
    mirror: boolean = true,
    sensitivity: number = 0.5
  ): { detection: GestureDetection; landmarks: Landmark[] | null } {
    if (video.readyState < 2) {
      return {
        detection: {
          direction: null,
          rawAngle: null,
          confidence: 0,
          isPinching: false,
          pinchDistance: 1,
          isOpenPalm: false,
          isFist: false,
          fingerTip: null,
          wrist: null,
          landmarksCount: 0,
          fps: this.currentFps,
          engineType: this.isAiModelReady() ? 'mediapipe_ai' : 'instant_optical',
          isSliding: false,
          slideVelocity: null,
          slideDirection: null,
        },
        landmarks: null,
      };
    }

    // If MediaPipe is NOT loaded yet, provide instant optical vision immediately!
    if (!this.handLandmarker) {
      const opticalDetection = opticalTracker.processFrame(video, mode, mirror, sensitivity);
      return {
        detection: opticalDetection,
        landmarks: null,
      };
    }

    // MediaPipe 21-Point AI Tracker
    this.fpsCounter++;
    const now = performance.now();
    if (now - this.lastFpsUpdate >= 1000) {
      this.currentFps = Math.round((this.fpsCounter * 1000) / (now - this.lastFpsUpdate));
      this.fpsCounter = 0;
      this.lastFpsUpdate = now;
    }

    const currentTime = video.currentTime > 0 ? video.currentTime * 1000 : now;
    const timestamp = currentTime > this.lastVideoTime ? currentTime : this.lastVideoTime + 1;
    this.lastVideoTime = timestamp;

    let results;
    try {
      results = this.handLandmarker.detectForVideo(video, timestamp);
    } catch {
      // If a frame fails in MediaPipe, fallback seamlessly to optical
      const opticalDetection = opticalTracker.processFrame(video, mode, mirror, sensitivity);
      return { detection: opticalDetection, landmarks: null };
    }

    if (!results.landmarks || results.landmarks.length === 0) {
      this.recentDirections = [];
      return {
        detection: {
          direction: null,
          rawAngle: null,
          confidence: 0,
          isPinching: false,
          pinchDistance: 1,
          isOpenPalm: false,
          isFist: false,
          fingerTip: null,
          wrist: null,
          landmarksCount: 0,
          fps: this.currentFps,
          engineType: 'mediapipe_ai',
          isSliding: false,
          slideVelocity: null,
          slideDirection: null,
        },
        landmarks: null,
      };
    }

    const landmarks = results.landmarks[0] as Landmark[];
    const wrist = landmarks[0];
    const thumbTip = landmarks[4];
    const indexMcp = landmarks[5];
    const indexPip = landmarks[6];
    const indexTip = landmarks[8];
    const middleTip = landmarks[12];
    const ringTip = landmarks[16];
    const pinkyTip = landmarks[20];

    const adjustX = (x: number) => (mirror ? 1 - x : x);

    const normWrist = { x: adjustX(wrist.x), y: wrist.y };
    const normIndexTip = { x: adjustX(indexTip.x), y: indexTip.y };
    const normIndexMcp = { x: adjustX(indexMcp.x), y: indexMcp.y };
    const normIndexPip = { x: adjustX(indexPip.x), y: indexPip.y };
    const normThumbTip = { x: adjustX(thumbTip.x), y: thumbTip.y };

    // Pinch detection
    const pinchDx = normThumbTip.x - normIndexTip.x;
    const pinchDy = normThumbTip.y - normIndexTip.y;
    const pinchDist = Math.hypot(pinchDx, pinchDy);
    const isPinching = pinchDist < 0.082;

    // Open Palm / Fist detection
    const dThumb = Math.hypot(thumbTip.x - wrist.x, thumbTip.y - wrist.y);
    const dIndex = Math.hypot(indexTip.x - wrist.x, indexTip.y - wrist.y);
    const dMiddle = Math.hypot(middleTip.x - wrist.x, middleTip.y - wrist.y);
    const dRing = Math.hypot(ringTip.x - wrist.x, ringTip.y - wrist.y);
    const dPinky = Math.hypot(pinkyTip.x - wrist.x, pinkyTip.y - wrist.y);
    const avgExtension = (dIndex + dMiddle + dRing + dPinky) / 4;

    const isOpenPalm = avgExtension > 0.38 && dThumb > 0.25;
    const isFist = avgExtension < 0.22;

    // Direction resolution
    let detectedDir: Direction | null = null;
    let rawAngle: number | null = null;
    let confidence = 0.95;

    if (mode === 'finger_point') {
      const dx = normIndexTip.x - normIndexMcp.x;
      const dy = normIndexTip.y - normIndexMcp.y;
      const magnitude = Math.hypot(dx, dy);
      const minDisplacement = 0.038 * (1.1 - sensitivity * 0.4);

      if (magnitude >= minDisplacement) {
        const rad = Math.atan2(dy, dx);
        rawAngle = (rad * 180) / Math.PI;

        if (rawAngle >= -45 && rawAngle <= 45) {
          detectedDir = 'RIGHT';
        } else if (rawAngle > 45 && rawAngle < 135) {
          detectedDir = 'DOWN';
        } else if (rawAngle < -45 && rawAngle > -135) {
          detectedDir = 'UP';
        } else {
          detectedDir = 'LEFT';
        }
      }
    } else if (mode === 'hand_quadrant') {
      const handCenterX = (normWrist.x + normIndexMcp.x) / 2;
      const handCenterY = (normWrist.y + normIndexMcp.y) / 2;
      const offX = handCenterX - 0.5;
      const offY = handCenterY - 0.5;
      const deadzone = 0.1 * (1.2 - sensitivity * 0.6);

      if (Math.hypot(offX, offY) > deadzone) {
        if (Math.abs(offX) > Math.abs(offY)) {
          detectedDir = offX > 0 ? 'RIGHT' : 'LEFT';
        } else {
          detectedDir = offY > 0 ? 'DOWN' : 'UP';
        }
      }
    } else {
      const dx = normIndexTip.x - normIndexPip.x;
      const dy = normIndexTip.y - normIndexPip.y;
      if (Math.hypot(dx, dy) > 0.04) {
        if (Math.abs(dx) > Math.abs(dy)) {
          detectedDir = dx > 0 ? 'RIGHT' : 'LEFT';
        } else {
          detectedDir = dy > 0 ? 'DOWN' : 'UP';
        }
      }
    }

    // Finger Slide Trajectory & Velocity Tracking
    this.tipHistory.push({ x: normIndexTip.x, y: normIndexTip.y, time: now });
    while (this.tipHistory.length > 0 && now - this.tipHistory[0].time > 160) {
      this.tipHistory.shift();
    }

    let isSliding = false;
    let slideDirection: Direction | null = null;
    let slideVelocity: { vx: number; vy: number; speed: number } | null = null;

    if (this.tipHistory.length >= 2) {
      const oldest = this.tipHistory[0];
      const deltaX = normIndexTip.x - oldest.x;
      const deltaY = normIndexTip.y - oldest.y;
      const dt = Math.max(1, now - oldest.time);
      const vx = deltaX / (dt / 1000);
      const vy = deltaY / (dt / 1000);
      const speed = Math.hypot(vx, vy);

      slideVelocity = { vx, vy, speed };

      const slideDist = Math.hypot(deltaX, deltaY);
      const minSlideDist = 0.024 * (1.1 - sensitivity * 0.4);
      if (slideDist > minSlideDist && speed > 0.2) {
        isSliding = true;
        if (Math.abs(deltaX) > Math.abs(deltaY)) {
          slideDirection = deltaX > 0 ? 'RIGHT' : 'LEFT';
        } else {
          slideDirection = deltaY > 0 ? 'DOWN' : 'UP';
        }
      }
    }

    // Finger slide takes immediate steering priority!
    if (isSliding && slideDirection) {
      detectedDir = slideDirection;
      this.lastConfirmedDirection = slideDirection;
    } else if (detectedDir) {
      this.recentDirections.push(detectedDir);
      if (this.recentDirections.length > 3) this.recentDirections.shift();
      const matchCount = this.recentDirections.filter((d) => d === detectedDir).length;
      if (matchCount >= 2) {
        this.lastConfirmedDirection = detectedDir;
      }
    }

    return {
      detection: {
        direction: this.lastConfirmedDirection || detectedDir,
        rawAngle,
        confidence,
        isPinching,
        pinchDistance: Math.min(1, pinchDist * 5),
        isOpenPalm,
        isFist,
        fingerTip: normIndexTip,
        wrist: normWrist,
        landmarksCount: landmarks.length,
        fps: this.currentFps,
        engineType: 'mediapipe_ai',
        isSliding,
        slideVelocity,
        slideDirection,
      },
      landmarks,
    };
  }

  public drawSkeleton(
    ctx: CanvasRenderingContext2D,
    landmarks: Landmark[],
    detection: GestureDetection,
    mirror: boolean,
    themeColor: string = '#06b6d4'
  ) {
    const width = ctx.canvas.width;
    const height = ctx.canvas.height;

    ctx.save();
    ctx.clearRect(0, 0, width, height);

    if (mirror) {
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
    }

    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    for (const [startIdx, endIdx] of HAND_CONNECTIONS) {
      const p1 = landmarks[startIdx];
      const p2 = landmarks[endIdx];
      if (!p1 || !p2) continue;

      const isIndexBone =
        (startIdx === 5 && endIdx === 6) ||
        (startIdx === 6 && endIdx === 7) ||
        (startIdx === 7 && endIdx === 8);

      ctx.shadowColor = isIndexBone ? '#f59e0b' : themeColor;
      ctx.shadowBlur = 8;
      ctx.strokeStyle = isIndexBone ? 'rgba(251, 191, 36, 0.95)' : 'rgba(34, 211, 238, 0.75)';

      ctx.beginPath();
      ctx.moveTo(p1.x * width, p1.y * height);
      ctx.lineTo(p2.x * width, p2.y * height);
      ctx.stroke();
    }

    for (let i = 0; i < landmarks.length; i++) {
      const p = landmarks[i];
      const x = p.x * width;
      const y = p.y * height;

      if (i === 8) {
        // Index pointer
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 14;
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(x, y, 7, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(x, y, 11, 0, Math.PI * 2);
        ctx.stroke();
      } else if (i === 4 && detection.isPinching) {
        ctx.shadowColor = '#ec4899';
        ctx.shadowBlur = 16;
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(x, y, 7, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.shadowColor = '#22d3ee';
        ctx.shadowBlur = 4;
        ctx.fillStyle = '#0891b2';
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    if (detection.isPinching) {
      const pThumb = landmarks[4];
      const pIndex = landmarks[8];
      if (pThumb && pIndex) {
        ctx.strokeStyle = '#ec4899';
        ctx.lineWidth = 4;
        ctx.shadowColor = '#f43f5e';
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.moveTo(pThumb.x * width, pThumb.y * height);
        ctx.lineTo(pIndex.x * width, pIndex.y * height);
        ctx.stroke();
      }
    }

    // Glowing finger slide comet trail
    if (this.tipHistory.length > 1) {
      for (let k = 1; k < this.tipHistory.length; k++) {
        const pt1 = this.tipHistory[k - 1];
        const pt2 = this.tipHistory[k];
        const alpha = (k / this.tipHistory.length) * 0.85;
        ctx.strokeStyle = `rgba(251, 191, 36, ${alpha})`;
        ctx.lineWidth = 2 + (k / this.tipHistory.length) * 3.5;
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        const x1 = (mirror ? 1 - pt1.x : pt1.x) * width;
        const y1 = pt1.y * height;
        const x2 = (mirror ? 1 - pt2.x : pt2.x) * width;
        const y2 = pt2.y * height;
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
    }

    ctx.restore();
  }
}

export const handTracker = new HandTrackerService();
