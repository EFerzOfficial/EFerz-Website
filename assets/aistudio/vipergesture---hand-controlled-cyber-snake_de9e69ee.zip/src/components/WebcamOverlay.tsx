import React, { useEffect, useRef, useState } from 'react';
import { Camera, CameraOff, RefreshCw, Eye, EyeOff, Zap, Compass, Cpu, Sparkles } from 'lucide-react';
import { Direction, GameSettings, GestureDetection } from '../types/game';
import { handTracker } from '../utils/handTracker';

interface WebcamOverlayProps {
  settings: GameSettings;
  onGesture: (detection: GestureDetection) => void;
  currentSnakeDir: Direction;
  isBoosting: boolean;
}

export const WebcamOverlay: React.FC<WebcamOverlayProps> = ({
  settings,
  onGesture,
  currentSnakeDir,
  isBoosting,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [aiLoaded, setAiLoaded] = useState<boolean>(() => handTracker.isAiModelReady());
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [detection, setDetection] = useState<GestureDetection | null>(null);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);

  // Initialize MediaPipe model asynchronously in background without blocking gameplay
  useEffect(() => {
    let isMounted = true;

    async function loadModel() {
      try {
        await handTracker.initialize();
        if (isMounted) {
          setAiLoaded(handTracker.isAiModelReady());
        }
      } catch (err) {
        console.warn('AI Vision load note:', err);
      }
    }

    loadModel();

    return () => {
      isMounted = false;
    };
  }, []);

  // Initialize Camera stream immediately
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Webcam API is not supported in this browser.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user',
        },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
          setCameraActive(true);
        };
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not access camera.';
      setCameraError(msg);
      setCameraActive(false);
    }
  };

  useEffect(() => {
    startCamera();

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // Frame processing loop - starts immediately on camera ready!
  useEffect(() => {
    let animId: number;

    const processFrame = () => {
      if (videoRef.current && cameraActive) {
        const video = videoRef.current;
        const canvas = canvasRef.current;

        if (video.readyState >= 2) {
          const { detection: currentDetection, landmarks } = handTracker.processVideoFrame(
            video,
            settings.controlMode,
            settings.mirrorCamera,
            settings.sensitivity
          );

          setDetection(currentDetection);
          onGesture(currentDetection);

          // Update AI status badge
          if (!aiLoaded && handTracker.isAiModelReady()) {
            setAiLoaded(true);
          }

          // Render skeleton or optical reticle on overlay canvas
          if (canvas && settings.showSkeleton) {
            const ctx = canvas.getContext('2d');
            if (ctx) {
              if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
                canvas.width = video.videoWidth || 320;
                canvas.height = video.videoHeight || 240;
              }

              if (landmarks && landmarks.length > 0) {
                // MediaPipe 21-point glowing skeleton
                handTracker.drawSkeleton(
                  ctx,
                  landmarks,
                  currentDetection,
                  settings.mirrorCamera,
                  '#06b6d4'
                );
              } else if (currentDetection.fingerTip) {
                // Instant Optical crosshair pointer
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                const tipX = currentDetection.fingerTip.x * canvas.width;
                const tipY = currentDetection.fingerTip.y * canvas.height;

                ctx.save();
                ctx.shadowColor = '#06b6d4';
                ctx.shadowBlur = 12;
                ctx.strokeStyle = '#22d3ee';
                ctx.lineWidth = 2.5;

                ctx.beginPath();
                ctx.arc(tipX, tipY, 12, 0, Math.PI * 2);
                ctx.stroke();

                ctx.fillStyle = '#38bdf8';
                ctx.beginPath();
                ctx.arc(tipX, tipY, 5, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
              } else {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
              }
            }
          }
        }
      }

      animId = requestAnimationFrame(processFrame);
    };

    animId = requestAnimationFrame(processFrame);
    return () => cancelAnimationFrame(animId);
  }, [cameraActive, settings, onGesture, aiLoaded]);

  const directionIcons: Record<Direction, string> = {
    UP: '▲ UP',
    DOWN: '▼ DOWN',
    LEFT: '◀ LEFT',
    RIGHT: '▶ RIGHT',
  };

  return (
    <div className="relative rounded-xl border border-slate-800 bg-slate-900/95 overflow-hidden shadow-2xl backdrop-blur-md flex flex-col">
      {/* HUD Header */}
      <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span
              className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                cameraActive ? 'bg-emerald-400' : 'bg-rose-500'
              }`}
            />
            <span
              className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
                cameraActive ? 'bg-emerald-500' : 'bg-rose-500'
              }`}
            />
          </span>

          <span className="text-xs font-semibold uppercase tracking-wider text-slate-300 font-mono flex items-center gap-1.5">
            {aiLoaded ? (
              <>
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                MediaPipe AI Vision
              </>
            ) : (
              <>
                <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                Instant Optical Vision
              </>
            )}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {detection && (
            <span className="text-[11px] font-mono text-cyan-400 font-bold">
              {detection.fps} FPS
            </span>
          )}
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="text-slate-400 hover:text-white transition-colors p-1 cursor-pointer"
            title={isMinimized ? 'Expand Camera' : 'Minimize Camera'}
          >
            {isMinimized ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {!isMinimized && (
        <div className="relative aspect-[4/3] bg-black overflow-hidden flex items-center justify-center">
          {/* Active Video Element */}
          <video
            ref={videoRef}
            playsInline
            muted
            className={`w-full h-full object-cover ${
              settings.mirrorCamera ? '-scale-x-100' : ''
            }`}
          />

          {/* Skeleton / Reticle Canvas */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full object-cover pointer-events-none"
          />

          {/* Camera Error State */}
          {cameraError && (
            <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-4 text-center gap-3">
              <CameraOff className="w-8 h-8 text-rose-400" />
              <p className="text-xs font-medium text-rose-300 max-w-[200px]">
                {cameraError}
              </p>
              <button
                onClick={startCamera}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" /> Retry Camera
              </button>
            </div>
          )}

          {/* Subtly indicating fast optical mode while MediaPipe initializes in background */}
          {!aiLoaded && cameraActive && (
            <div className="absolute top-2 right-2 bg-slate-950/80 border border-emerald-500/40 text-emerald-300 px-2 py-0.5 rounded text-[10px] font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Zero-Wait Fast Track
            </div>
          )}

          {/* Live Gesture Compass Banner */}
          {detection?.direction && (
            <div className="absolute top-3 left-3 flex items-center pointer-events-none">
              <div className="bg-slate-950/90 border border-cyan-500/60 text-cyan-300 px-2.5 py-1 rounded shadow-lg backdrop-blur-md flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-xs font-bold font-mono tracking-wider">
                  {directionIcons[detection.direction]}
                </span>
              </div>
            </div>
          )}

          {/* Finger Slide Instant Action Indicator */}
          {detection?.isSliding && detection.slideDirection && (
            <div className="absolute top-12 left-3 flex items-center pointer-events-none">
              <div className="bg-amber-400 text-slate-950 font-black px-2.5 py-0.5 rounded shadow-lg text-[10px] font-mono tracking-wide flex items-center gap-1 animate-pulse">
                ⚡ FINGER SLIDE {directionIcons[detection.slideDirection]}
              </div>
            </div>
          )}

          {/* Pinch Turbo Indicator */}
          {detection?.isPinching && (
            <div className="absolute bottom-3 left-3 bg-amber-500/95 text-slate-950 px-2.5 py-1 rounded shadow-lg font-bold font-mono text-xs flex items-center gap-1 animate-pulse">
              <Zap className="w-3.5 h-3.5 fill-current" />
              TURBO PINCH
            </div>
          )}

          {/* Palm Pause Indicator */}
          {detection?.isOpenPalm && (
            <div className="absolute bottom-3 right-3 bg-purple-600/90 text-white px-2.5 py-1 rounded shadow-lg font-bold font-mono text-xs flex items-center gap-1">
              ✋ PALM PAUSE
            </div>
          )}
        </div>
      )}

      {/* Sensor Status Footer */}
      <div className="p-3 bg-slate-950 border-t border-slate-800 flex flex-col gap-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400">Target Direction:</span>
          <span
            className={`font-bold ${
              detection?.direction ? 'text-cyan-400' : 'text-slate-500'
            }`}
          >
            {detection?.direction ? directionIcons[detection.direction] : 'POINT YOUR FINGER'}
          </span>
        </div>

        {/* Real-time Pinch Boost Bar */}
        <div className="flex flex-col gap-1">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span className="flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-400" /> Pinch Turbo Meter:
            </span>
            <span className={isBoosting ? 'text-amber-400 font-bold' : 'text-slate-500'}>
              {isBoosting ? 'ENGAGED 2.2X' : 'Pinch thumb+index'}
            </span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-75 ${
                isBoosting ? 'bg-amber-400 w-full shadow-lg shadow-amber-400/50' : 'bg-slate-600'
              }`}
              style={{
                width: isBoosting ? '100%' : `${Math.max(10, (1 - (detection?.pinchDistance || 1)) * 100)}%`,
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
