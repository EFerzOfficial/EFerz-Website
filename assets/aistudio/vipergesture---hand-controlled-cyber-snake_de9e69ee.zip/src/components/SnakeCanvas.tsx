import React, { useEffect, useRef } from 'react';
import { GameEngine, GRID_SIZE } from '../utils/gameEngine';
import { Direction, GameSettings } from '../types/game';

interface SnakeCanvasProps {
  engine: GameEngine;
  settings: GameSettings;
  isPaused: boolean;
  isBoosting: boolean;
  detectedDirection: Direction | null;
}

export const SnakeCanvas: React.FC<SnakeCanvasProps> = ({
  engine,
  settings,
  isPaused,
  isBoosting,
  detectedDirection,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    let animId: number;

    const render = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const width = canvas.width;
      const height = canvas.height;
      const cellSize = width / GRID_SIZE;

      ctx.clearRect(0, 0, width, height);

      // Background Cyber Matrix
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, width, height);

      // Cyber Grid Lines
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.45)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= GRID_SIZE; i++) {
        const pos = i * cellSize;
        ctx.beginPath();
        ctx.moveTo(pos, 0);
        ctx.lineTo(pos, height);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(0, pos);
        ctx.lineTo(width, pos);
        ctx.stroke();
      }

      // Border walls
      ctx.strokeStyle = settings.wrapAround ? 'rgba(56, 189, 248, 0.25)' : 'rgba(239, 68, 68, 0.7)';
      ctx.lineWidth = 3;
      ctx.strokeRect(1.5, 1.5, width - 3, height - 3);

      // Obstacles
      if (engine.obstacles.length > 0) {
        ctx.shadowColor = '#f43f5e';
        ctx.shadowBlur = 10;
        ctx.fillStyle = 'rgba(225, 29, 72, 0.85)';
        for (const obs of engine.obstacles) {
          const ox = obs.x * cellSize;
          const oy = obs.y * cellSize;
          ctx.fillRect(ox + 2, oy + 2, cellSize - 4, cellSize - 4);
          // Warning cross
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(ox + 4, oy + 4);
          ctx.lineTo(ox + cellSize - 4, oy + cellSize - 4);
          ctx.moveTo(ox + cellSize - 4, oy + 4);
          ctx.lineTo(ox + 4, oy + cellSize - 4);
          ctx.stroke();
        }
      }

      // Draw Foods
      const now = Date.now();
      for (const food of engine.foods) {
        const fx = food.position.x * cellSize;
        const fy = food.position.y * cellSize;
        const centerX = fx + cellSize / 2;
        const centerY = fy + cellSize / 2;
        const pulse = Math.sin(now * 0.007) * 2;

        ctx.save();
        if (food.type === 'standard') {
          // Neon Byte
          ctx.shadowColor = '#22c55e';
          ctx.shadowBlur = 14 + pulse * 2;
          ctx.fillStyle = '#4ade80';

          const size = cellSize * 0.75 + pulse;
          ctx.beginPath();
          ctx.roundRect(centerX - size / 2, centerY - size / 2, size, size, 4);
          ctx.fill();

          // Core shine
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(centerX, centerY, size * 0.25, 0, Math.PI * 2);
          ctx.fill();
        } else if (food.type === 'golden') {
          // Golden Core (Star / Diamond with rotating ring)
          ctx.shadowColor = '#eab308';
          ctx.shadowBlur = 20 + pulse * 3;
          ctx.fillStyle = '#fde047';

          ctx.beginPath();
          ctx.arc(centerX, centerY, (cellSize / 2) * 0.75 + pulse, 0, Math.PI * 2);
          ctx.fill();

          // Rotating orbit
          const angle = (now * 0.004) % (Math.PI * 2);
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.ellipse(centerX, centerY, cellSize * 0.55, cellSize * 0.28, angle, 0, Math.PI * 2);
          ctx.stroke();
        } else if (food.type === 'freeze') {
          // Freeze Glitch
          ctx.shadowColor = '#06b6d4';
          ctx.shadowBlur = 16;
          ctx.fillStyle = '#38bdf8';

          const size = cellSize * 0.8;
          ctx.beginPath();
          ctx.moveTo(centerX, centerY - size / 2);
          ctx.lineTo(centerX + size / 2, centerY);
          ctx.lineTo(centerX, centerY + size / 2);
          ctx.lineTo(centerX - size / 2, centerY);
          ctx.closePath();
          ctx.fill();

          ctx.strokeStyle = '#e0f2fe';
          ctx.lineWidth = 2;
          ctx.stroke();
        } else if (food.type === 'quantum') {
          // Quantum Phase Orb
          ctx.shadowColor = '#d946ef';
          ctx.shadowBlur = 18 + pulse * 4;
          ctx.fillStyle = '#ec4899';

          ctx.beginPath();
          ctx.arc(centerX, centerY, (cellSize / 2) * 0.8 + pulse, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = '#f472b6';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(centerX, centerY, (cellSize / 2) * 1.05 + pulse, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.restore();
      }

      // Draw Smooth Interpolated Snake Body
      const { positions: interpSnake, headAngle } = engine.getInterpolatedPositions(performance.now());
      const isQuantum = engine.activePowerup?.type === 'quantum';
      const isFreeze = engine.activePowerup?.type === 'freeze';

      // Theme Colors
      let headColor = '#06b6d4';
      let bodyStart = '#22d3ee';
      let bodyEnd = '#0284c7';
      let glowColor = '#06b6d4';

      if (settings.theme === 'synthwave-magenta') {
        headColor = '#ec4899';
        bodyStart = '#f43f5e';
        bodyEnd = '#a855f7';
        glowColor = '#ec4899';
      } else if (settings.theme === 'matrix-green') {
        headColor = '#22c55e';
        bodyStart = '#4ade80';
        bodyEnd = '#15803d';
        glowColor = '#22c55e';
      } else if (settings.theme === 'laser-amber') {
        headColor = '#f59e0b';
        bodyStart = '#fbbf24';
        bodyEnd = '#d97706';
        glowColor = '#f59e0b';
      }

      if (isQuantum) {
        headColor = '#f43f5e';
        bodyStart = '#ec4899';
        bodyEnd = '#9333ea';
        glowColor = '#f43f5e';
      } else if (isFreeze) {
        headColor = '#38bdf8';
        bodyStart = '#7dd3fc';
        bodyEnd = '#0284c7';
        glowColor = '#38bdf8';
      }

      if (isBoosting) {
        glowColor = '#f97316';
      }

      // Draw body segments with smooth interpolated positions (from tail to neck)
      for (let i = interpSnake.length - 1; i >= 1; i--) {
        const seg = interpSnake[i];
        const progress = i / interpSnake.length; // 0 near head, 1 at tail
        const sx = seg.x * cellSize;
        const sy = seg.y * cellSize;

        const pad = Math.min(cellSize * 0.18, 1 + progress * 2.5);
        const radius = Math.max(3, (cellSize - pad * 2) / 3);

        ctx.save();
        ctx.shadowColor = glowColor;
        ctx.shadowBlur = isBoosting ? 14 : isQuantum ? 16 : 8;

        // Gradient interpolation
        ctx.fillStyle = bodyStart;
        if (isQuantum) {
          ctx.globalAlpha = 0.65 + Math.sin(now * 0.01 + i) * 0.25;
        }

        ctx.beginPath();
        ctx.roundRect(
          sx + pad,
          sy + pad,
          cellSize - pad * 2,
          cellSize - pad * 2,
          radius
        );
        ctx.fill();

        // Inner glowing spine line
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();
      }

      // Draw Snake Head with continuous smooth rotation
      if (interpSnake.length > 0) {
        const head = interpSnake[0];
        const cx = head.x * cellSize + cellSize / 2;
        const cy = head.y * cellSize + cellSize / 2;
        const hs = cellSize * 0.9;

        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(headAngle);

        ctx.shadowColor = isBoosting ? '#f97316' : glowColor;
        ctx.shadowBlur = isBoosting ? 24 : 18;
        ctx.fillStyle = isBoosting ? '#ffedd5' : '#ffffff';

        // Head capsule
        ctx.beginPath();
        ctx.roundRect(-hs / 2, -hs / 2, hs, hs, 7);
        ctx.fill();

        ctx.fillStyle = headColor;
        ctx.beginPath();
        ctx.roundRect(-hs / 2 + 2, -hs / 2 + 2, hs - 4, hs - 4, 5);
        ctx.fill();

        // Cyber Visor Eyes (facing direction of rotation)
        ctx.fillStyle = isBoosting ? '#ea580c' : '#0369a1';
        ctx.shadowColor = '#ffffff';
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.arc(hs * 0.2, -hs * 0.25, 2.5, 0, Math.PI * 2);
        ctx.arc(hs * 0.2, hs * 0.25, 2.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();

        // Direction steering indicator preview arrow
        if (detectedDirection && detectedDirection !== engine.currentDirection) {
          ctx.save();
          ctx.strokeStyle = '#facc15';
          ctx.lineWidth = 2.5;
          ctx.shadowColor = '#facc15';
          ctx.shadowBlur = 10;
          ctx.beginPath();
          let arrowDx = 0;
          let arrowDy = 0;
          if (detectedDirection === 'UP') arrowDy = -cellSize * 0.9;
          if (detectedDirection === 'DOWN') arrowDy = cellSize * 0.9;
          if (detectedDirection === 'LEFT') arrowDx = -cellSize * 0.9;
          if (detectedDirection === 'RIGHT') arrowDx = cellSize * 0.9;
          ctx.moveTo(cx, cy);
          ctx.lineTo(cx + arrowDx, cy + arrowDy);
          ctx.stroke();
          ctx.restore();
        }
      }

      // Draw Particles
      engine.updateParticles();
      for (const p of engine.particles) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.arc(p.x * cellSize, p.y * cellSize, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Pause Dim
      if (isPaused) {
        ctx.fillStyle = 'rgba(10, 15, 29, 0.65)';
        ctx.fillRect(0, 0, width, height);

        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 28px "Chakra Petch", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('PAUSED', width / 2, height / 2 - 10);

        ctx.fillStyle = '#94a3b8';
        ctx.font = '14px "JetBrains Mono", monospace';
        ctx.fillText('Show palm or click resume', width / 2, height / 2 + 20);
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [engine, settings, isPaused, isBoosting, detectedDirection]);

  return (
    <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl flex items-center justify-center">
      <canvas
        ref={canvasRef}
        width={650}
        height={650}
        className="w-full max-w-[620px] aspect-square object-contain block touch-none"
      />
    </div>
  );
};
