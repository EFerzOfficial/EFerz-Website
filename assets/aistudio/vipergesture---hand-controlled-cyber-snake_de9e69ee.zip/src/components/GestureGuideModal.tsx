import React from 'react';
import { X, Hand, Zap, Pause, Target, Compass, CheckCircle2 } from 'lucide-react';

interface GestureGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GestureGuideModal: React.FC<GestureGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Hand className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-white font-mono tracking-wide">
              Hand Gesture Control Manual
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[75vh] space-y-5 text-slate-300 text-sm">
          {/* Card 1: Finger Pointing */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-cyan-900/40 flex gap-4 items-start">
            <div className="p-3 bg-cyan-950/60 border border-cyan-500/30 rounded-xl text-cyan-400 shrink-0">
              <Compass className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-white text-base font-mono flex items-center gap-2">
                1. Steer with Finger Slide or Point
              </h3>
              <p className="text-slate-400 leading-relaxed text-xs">
                In just a <strong className="text-cyan-300">quick finger slide or swipe</strong> in the air (slide Up, Down, Left, or Right), the snake glides smoothly in that direction with continuous 60 FPS sub-pixel interpolation. You can also point your finger directly to steer.
              </p>
              <div className="grid grid-cols-4 gap-2 pt-2 text-center text-xs font-mono">
                <div className="p-1.5 bg-slate-900 rounded border border-slate-800 text-cyan-300">
                  👆 Slide Up
                </div>
                <div className="p-1.5 bg-slate-900 rounded border border-slate-800 text-cyan-300">
                  👇 Slide Down
                </div>
                <div className="p-1.5 bg-slate-900 rounded border border-slate-800 text-cyan-300">
                  👈 Slide Left
                </div>
                <div className="p-1.5 bg-slate-900 rounded border border-slate-800 text-cyan-300">
                  👉 Slide Right
                </div>
              </div>
            </div>
          </div>

          {/* Card 2: Pinch Turbo */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-amber-900/40 flex gap-4 items-start">
            <div className="p-3 bg-amber-950/60 border border-amber-500/30 rounded-xl text-amber-400 shrink-0">
              <Zap className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-white text-base font-mono flex items-center gap-2">
                2. Pinch for Turbo Boost
              </h3>
              <p className="text-slate-400 leading-relaxed text-xs">
                Bring your <strong className="text-amber-300">Thumb and Index fingertips together</strong> (a pinch or OK sign).
                This activates hyper-speed turbo boost to rush towards bonus food or dodge incoming walls! Release pinch to return to normal speed.
              </p>
            </div>
          </div>

          {/* Card 3: Open Palm Pause */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-purple-900/40 flex gap-4 items-start">
            <div className="p-3 bg-purple-950/60 border border-purple-500/30 rounded-xl text-purple-400 shrink-0">
              <Pause className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-white text-base font-mono flex items-center gap-2">
                3. Open Palm to Pause / Resume
              </h3>
              <p className="text-slate-400 leading-relaxed text-xs">
                Show an open flat palm (all 5 fingers spread out facing the webcam) to instantly pause or unpause the game without touching your keyboard.
              </p>
            </div>
          </div>

          {/* Card 4: Pro Tips */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-cyan-400" />
              Pro Tips for Zero Latency
            </h4>
            <ul className="text-xs text-slate-400 space-y-1.5">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                Keep your hand 1.5 to 2.5 feet (45–75 cm) in front of your laptop camera.
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                Ensure comfortable ambient room lighting so fingers cast clear silhouettes.
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                Keyboard arrows or W/A/S/D and Spacebar can also be used as instant fallback at any time.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/70 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono rounded-lg transition-colors cursor-pointer text-xs"
          >
            LET'S PLAY
          </button>
        </div>
      </div>
    </div>
  );
};
