import React from 'react';
import { X, Sliders, Volume2, VolumeX, Shield, Video, Flame, Sparkles } from 'lucide-react';
import { ControlMode, GameSettings } from '../types/game';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-white font-mono tracking-wide">
              Configuration & Hardware
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[75vh] space-y-6 text-sm">
          {/* Section: Gesture Control Mode */}
          <div className="space-y-2">
            <label className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold block">
              Gesture Tracking Strategy
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'finger_point', label: 'Finger Vector', desc: 'Point with index finger' },
                { id: 'hand_quadrant', label: 'Screen Zones', desc: 'Hand in screen region' },
                { id: 'swipe', label: 'Swipe Flicks', desc: 'Quick hand directional flicks' },
              ].map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => onUpdateSettings({ controlMode: mode.id as ControlMode })}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    settings.controlMode === mode.id
                      ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200 shadow-sm shadow-cyan-950'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <div className="font-bold font-mono text-xs">{mode.label}</div>
                  <div className="text-[11px] text-slate-500 mt-1">{mode.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Section: Gesture Sensitivity */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-300 font-bold">Finger Movement Sensitivity</span>
              <span className="text-cyan-400">{Math.round(settings.sensitivity * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="1.0"
              step="0.05"
              value={settings.sensitivity}
              onChange={(e) => onUpdateSettings({ sensitivity: parseFloat(e.target.value) })}
              className="w-full accent-cyan-400 bg-slate-800 rounded-lg cursor-pointer h-2"
            />
            <div className="flex justify-between text-[11px] text-slate-500 font-mono">
              <span>Deliberate / Strict</span>
              <span>Ultra Responsive</span>
            </div>
          </div>

          {/* Section: Game Speed / Difficulty */}
          <div className="space-y-2">
            <label className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold block">
              Tempo / Difficulty
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'relaxed', label: 'Relaxed', desc: '150ms per step' },
                { id: 'arcade', label: 'Arcade', desc: '110ms per step' },
                { id: 'hyper', label: 'Hyper Cyber', desc: '80ms per step' },
              ].map((lvl) => (
                <button
                  key={lvl.id}
                  onClick={() => onUpdateSettings({ speed: lvl.id as GameSettings['speed'] })}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    settings.speed === lvl.id
                      ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold font-mono text-xs">{lvl.label}</div>
                  <div className="text-[10px] text-slate-500">{lvl.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Section: Theme */}
          <div className="space-y-2">
            <label className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold block">
              Cyber Skin Aesthetics
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'cyber-cyan', label: 'Cyan', color: '#06b6d4' },
                { id: 'synthwave-magenta', label: 'Synthwave', color: '#ec4899' },
                { id: 'matrix-green', label: 'Matrix', color: '#22c55e' },
                { id: 'laser-amber', label: 'Amber', color: '#f59e0b' },
              ].map((thm) => (
                <button
                  key={thm.id}
                  onClick={() => onUpdateSettings({ theme: thm.id as GameSettings['theme'] })}
                  className={`p-2 rounded-lg border text-center flex flex-col items-center gap-1.5 transition-all ${
                    settings.theme === thm.id
                      ? 'border-white bg-slate-800 text-white'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div
                    className="w-4 h-4 rounded-full border border-white/40 shadow-sm"
                    style={{ backgroundColor: thm.color }}
                  />
                  <span className="text-[11px] font-mono">{thm.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white font-mono">Wrap-Around Screen Walls</div>
                <div className="text-[11px] text-slate-500">Passing through one edge emerges on the opposite</div>
              </div>
              <input
                type="checkbox"
                checked={settings.wrapAround}
                onChange={(e) => onUpdateSettings({ wrapAround: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white font-mono">Cyber Obstacle Pylons</div>
                <div className="text-[11px] text-slate-500">Spawn collision pylons for tactical maneuvering</div>
              </div>
              <input
                type="checkbox"
                checked={settings.obstaclesEnabled}
                onChange={(e) => onUpdateSettings({ obstaclesEnabled: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white font-mono">Mirror Camera Preview</div>
                <div className="text-[11px] text-slate-500">Horizontal flip for natural selfie mirror reflection</div>
              </div>
              <input
                type="checkbox"
                checked={settings.mirrorCamera}
                onChange={(e) => onUpdateSettings({ mirrorCamera: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white font-mono">Render Skeleton Landmarks</div>
                <div className="text-[11px] text-slate-500">Display AI joint tracking lines on webcam feed</div>
              </div>
              <input
                type="checkbox"
                checked={settings.showSkeleton}
                onChange={(e) => onUpdateSettings({ showSkeleton: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white font-mono">Web Audio Sound FX</div>
                <div className="text-[11px] text-slate-500">Futuristic synth chimes and crash sounds</div>
              </div>
              <input
                type="checkbox"
                checked={settings.soundEnabled}
                onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/70 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold font-mono rounded-lg transition-colors cursor-pointer text-xs"
          >
            SAVE PREFERENCES
          </button>
        </div>
      </div>
    </div>
  );
};
