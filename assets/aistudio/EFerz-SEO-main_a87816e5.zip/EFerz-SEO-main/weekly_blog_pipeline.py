#!/usr/bin/env python3
"""
weekly_blog_pipeline.py

Runs weekly (via GitHub Actions). Does all of this automatically:
  1. Asks Claude for a fresh tech/agency-related blog topic + full article + SEO meta.
  2. Downloads 2-3 relevant free stock clips from Pexels.
  3. Generates a short AI voice narration (free, no API key) of the article summary.
  4. Assembles a vertical (1080x1920) short video with captions + narration —
     usable for YouTube Shorts / Instagram Reels / Facebook Reels.
  5. Generates a featured blog image with the title text on it.
  6. Publishes the blog post directly to WordPress (title, content, meta, featured
     image, and the video file), and logs the topic so future posts don't repeat it.

Required environment variables (set as GitHub Secrets):
  GEMINI_API_KEY, PEXELS_API_KEY, WP_BASE_URL, WP_USERNAME, WP_APP_PASSWORD

Both GEMINI_API_KEY and PEXELS_API_KEY have permanent free tiers (no credit card,
no cost) that are more than enough for one post a week.
"""

import os
import sys
import json
import csv
import asyncio
import requests

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")  # optional, unused by default
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
PEXELS_API_KEY = os.environ.get("PEXELS_API_KEY", "")
WP_BASE_URL = os.environ.get("WP_BASE_URL", "").rstrip("/")
WP_USERNAME = os.environ.get("WP_USERNAME", "")
WP_APP_PASSWORD = os.environ.get("WP_APP_PASSWORD", "")

TOPIC_LOG_PATH = "seo-data/blog-topics-log.csv"
WORKDIR = "blog_build"
HTTP_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Accept": "application/json, */*",
}

BRAND_COLOR = (17, 24, 39)       # dark navy background for image/video captions
ACCENT_COLOR = (56, 189, 248)    # EFerz-style light blue accent
CAPTION_HIGHLIGHT_COLOR = (220, 38, 38)  # red — matches EFerz website theme


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def check_env():
    missing = [k for k, v in {
        "GEMINI_API_KEY": GEMINI_API_KEY,
        "PEXELS_API_KEY": PEXELS_API_KEY,
        "WP_BASE_URL": WP_BASE_URL,
        "WP_USERNAME": WP_USERNAME,
        "WP_APP_PASSWORD": WP_APP_PASSWORD,
    }.items() if not v]
    if missing:
        die(f"Missing required environment variables: {', '.join(missing)}")


# ---------------------------------------------------------------------------
# 1. Content generation via Claude
# ---------------------------------------------------------------------------

CATEGORIES = [
    "Web Design", "Digital Marketing", "SEO", "E-Commerce",
    "Cybersecurity", "AI Tools", "Branding", "Amazon FBA",
]

CATEGORY_TO_SERVICE_SLUG = {
    "Web Design": "web-design-development",
    "Digital Marketing": "digital-marketing",
    "SEO": "digital-marketing",
    "E-Commerce": "e-commerce-solution",
    "Cybersecurity": "cyber-security",
    "AI Tools": "consulting-services",
    "Branding": "brand-development",
    "Amazon FBA": "amazon-fba",
}


def load_recent_topics(limit=20):
    if not os.path.exists(TOPIC_LOG_PATH):
        return []
    with open(TOPIC_LOG_PATH, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    return [r["title"] for r in rows[-limit:]]


def generate_article():
    recent = load_recent_topics()
    avoid_note = ""
    if recent:
        avoid_note = "Do NOT repeat or closely resemble any of these previous topics:\n" + \
            "\n".join(f"- {t}" for t in recent)

    system_prompt = (
        "You are the content writer for EFerz, a digital agency (web design, digital "
        "marketing, e-commerce, cybersecurity, Amazon FBA, branding) serving clients in "
        "the USA and Saudi Arabia, whose slogan is 'Nothing Impossible in IT World'. "
        "Write one practical, useful weekly blog post about a technology or digital-agency "
        "related tip/trend (e.g. web design best practices, SEO tricks, e-commerce growth, "
        "cybersecurity basics, AI tools for business, social media marketing tips). "
        "Keep it genuinely useful and specific, not generic filler. "
        f"{avoid_note}\n\n"
        f"Pick ONE category for this post from exactly this list: {', '.join(CATEGORIES)}.\n\n"
        "Respond with ONLY a JSON object (no markdown fences, no preamble) with these exact keys:\n"
        '{"title": "...", "slug": "...", "category": "...", "content_html": "...", '
        '"meta_title": "...", '
        '"meta_description": "...", "meta_keywords": "...", "focus_keyword": "...", '
        '"pexels_search_terms": ["...", "...", "..."], "narration_script": "..."}\n\n'
        "Rules:\n"
        "- content_html: 600-900 words, valid HTML using <h2>, <p>, <ul>/<li> tags only "
        "(no <html>/<body> wrapper).\n"
        "- Insert exactly two image placeholders on their own line, written literally as "
        "{{IMAGE_1}} and {{IMAGE_2}} — place {{IMAGE_1}} after the intro/first section, and "
        "{{IMAGE_2}} roughly two-thirds through the article. Do not describe or caption them.\n"
        "- Do NOT write your own call-to-action or mention EFerz's services yourself — that "
        "will be appended separately.\n"
        "- meta_title: under 60 characters. meta_description: under 155 characters.\n"
        "- pexels_search_terms: 3 short (1-3 word) English search terms for relevant "
        "stock footage (e.g. ['laptop coding', 'office team meeting', 'website design']).\n"
        "- narration_script: a 110-150 word spoken-style summary, for text-to-speech "
        "narration in a short video. Conversational, no headings. CRITICAL for retention: "
        "the very first sentence must be a strong hook — a surprising fact, a bold claim, "
        "or a direct question that stops someone from scrolling (e.g. 'Your website is "
        "losing you customers, and here's why' — not 'Today we'll talk about...'). Use "
        "short punchy sentences throughout, not long ones. End with a clear one-line "
        "takeaway, not a trailing thought."
    )

    # Primary model first, then fall back to a second model if the primary
    # keeps returning 503/overloaded after all its own retries are exhausted.
    # This handles sustained Google-side outages (not just brief blips) without
    # failing the whole weekly run.
    # NOTE: "gemini-2.5-flash" was retired by Google (now returns 404 "no longer
    # available to new users") and has been replaced with "gemini-3.8-flash",
    # which is the model Google's own error message pointed to as the successor.
    MODEL_CHAIN = ["gemini-3.6-flash", "gemini-flash-latest", "gemini-3.8-flash"]
    MAX_ATTEMPTS_PER_MODEL = 4
    BACKOFF_SCHEDULE = [15, 30, 60]  # seconds, between attempts within a model

    article = None
    last_error = ""
    import time

    for model_name in MODEL_CHAIN:
        model_failed_hard = False
        for attempt in range(1, MAX_ATTEMPTS_PER_MODEL + 1):
            resp = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model_name}:generateContent",
                params={"key": GEMINI_API_KEY},
                headers={"content-type": "application/json"},
                json={
                    "systemInstruction": {"parts": [{"text": system_prompt}]},
                    "contents": [{"role": "user", "parts": [
                        {"text": "Write this week's blog post now."}
                    ]}],
                    "generationConfig": {
                        "temperature": 0.9,
                        "maxOutputTokens": 8192,
                        "responseMimeType": "application/json",
                    },
                },
                timeout=120,
            )

            if resp.status_code != 200:
                last_error = f"Gemini API error {resp.status_code} ({model_name}): {resp.text[:400]}"
                if resp.status_code in (429, 500, 502, 503, 504) and attempt < MAX_ATTEMPTS_PER_MODEL:
                    wait = BACKOFF_SCHEDULE[min(attempt - 1, len(BACKOFF_SCHEDULE) - 1)]
                    print(f"  Gemini API returned {resp.status_code} on {model_name} "
                          f"(attempt {attempt}/{MAX_ATTEMPTS_PER_MODEL}) — "
                          f"this is usually a temporary hiccup on Google's side, retrying in {wait}s...")
                    time.sleep(wait)
                    continue
                # Exhausted retries on this model — try the next model in the chain.
                model_failed_hard = True
                break

            result = resp.json()
            try:
                candidate = result["candidates"][0]
                text = candidate["content"]["parts"][0]["text"].strip()
                finish_reason = candidate.get("finishReason", "")
            except (KeyError, IndexError):
                last_error = f"Unexpected Gemini response shape ({model_name}): {json.dumps(result)[:500]}"
                model_failed_hard = True
                break

            text = text.strip("`")
            if text.lower().startswith("json"):
                text = text[4:].strip()
            try:
                article = json.loads(text)
                break  # success
            except json.JSONDecodeError as e:
                last_error = (f"Could not parse Gemini's JSON response ({model_name}, "
                               f"finishReason={finish_reason}, {len(text)} chars received, "
                               f"error at char {e.pos}): {text[max(0,e.pos-80):e.pos+80]}")
                if attempt < MAX_ATTEMPTS_PER_MODEL:
                    print(f"  Gemini returned malformed JSON on {model_name} "
                          f"(attempt {attempt}/{MAX_ATTEMPTS_PER_MODEL}) — "
                          f"this is an occasional generation glitch, retrying...")
                    continue
                model_failed_hard = True
                break

        if article is not None:
            break
        if model_failed_hard and model_name != MODEL_CHAIN[-1]:
            print(f"  {model_name} unavailable after {MAX_ATTEMPTS_PER_MODEL} attempts — "
                  f"falling back to next model...")

    if article is None:
        die(last_error or "Gemini API call failed for an unknown reason.")

    required = ["title", "slug", "category", "content_html", "meta_title", "meta_description",
                "meta_keywords", "focus_keyword", "pexels_search_terms", "narration_script"]
    for key in required:
        if key not in article:
            die(f"Claude's response is missing '{key}'")
    return article


# ---------------------------------------------------------------------------
# 2. Pexels stock footage + photo
# ---------------------------------------------------------------------------

def fetch_pexels_clips(search_terms, out_dir, max_clips=3):
    os.makedirs(out_dir, exist_ok=True)
    clip_paths = []
    for i, term in enumerate(search_terms[:max_clips]):
        resp = requests.get(
            "https://api.pexels.com/videos/search",
            headers={"Authorization": PEXELS_API_KEY},
            params={"query": term, "orientation": "portrait", "per_page": 3},
            timeout=30,
        )
        if resp.status_code != 200 or not resp.json().get("videos"):
            print(f"  Pexels: no video results for '{term}' (status {resp.status_code})")
            continue
        video = resp.json()["videos"][0]
        # pick a moderate-resolution file (~720p) to keep downloads/processing fast
        files = sorted(video["video_files"], key=lambda f: f.get("width") or 0)
        chosen = next((f for f in files if (f.get("width") or 0) >= 720), files[-1])
        clip_path = os.path.join(out_dir, f"clip_{i}.mp4")
        r = requests.get(chosen["link"], headers=HTTP_HEADERS, timeout=60)
        with open(clip_path, "wb") as f:
            f.write(r.content)
        clip_paths.append(clip_path)
        print(f"  Downloaded clip for '{term}' -> {clip_path}")
    return clip_paths


def fetch_pexels_photo(search_term, out_path):
    resp = requests.get(
        "https://api.pexels.com/v1/search",
        headers={"Authorization": PEXELS_API_KEY},
        params={"query": search_term, "orientation": "landscape", "per_page": 1},
        timeout=30,
    )
    if resp.status_code != 200 or not resp.json().get("photos"):
        return None
    photo_url = resp.json()["photos"][0]["src"]["large2x"]
    r = requests.get(photo_url, headers=HTTP_HEADERS, timeout=60)
    with open(out_path, "wb") as f:
        f.write(r.content)
    return out_path


def insert_inline_images(session, content_html, search_terms, article, out_dir):
    """Downloads 2 extra Pexels photos, uploads them to the WP media library, and
    replaces the {{IMAGE_1}}/{{IMAGE_2}} placeholders in the article with real
    <figure><img></figure> tags (with SEO-friendly alt text)."""
    terms = (search_terms[1:3] or search_terms[:2] or ["technology"])
    for i, term in enumerate(terms[:2], start=1):
        placeholder = "{{IMAGE_%d}}" % i
        if placeholder not in content_html:
            continue
        local_path = os.path.join(out_dir, f"inline_{i}.jpg")
        if not fetch_pexels_photo(term, local_path):
            content_html = content_html.replace(placeholder, "")
            continue
        alt_text = f"{article['focus_keyword']} - {term}"
        media_id, media_url = wp_upload_media(session, local_path, "image/jpeg", alt_text)
        img_tag = (
            f'<figure class="wp-block-image size-large">'
            f'<img src="{media_url}" alt="{alt_text}" loading="lazy" /></figure>'
        )
        content_html = content_html.replace(placeholder, img_tag)
    # Clean up any leftover placeholder if a term/fetch failed silently
    content_html = content_html.replace("{{IMAGE_1}}", "").replace("{{IMAGE_2}}", "")
    return content_html


def append_cta(content_html, article):
    slug = CATEGORY_TO_SERVICE_SLUG.get(article["category"], "contact-us")
    return content_html + (
        f'\n<!-- wp:paragraph --><p>Want help with this for your own business? '
        f'<a href="{WP_BASE_URL}/{slug}/">Talk to EFerz about {article["category"]} '
        f'services</a> — or <a href="{WP_BASE_URL}/contact-us/">contact us</a> for a '
        f'free strategy session.</p><!-- /wp:paragraph -->\n'
    )


# ---------------------------------------------------------------------------
# 3. Free narration (Microsoft Edge neural TTS, no API key required)
# ---------------------------------------------------------------------------

async def _generate_narration_async(text, out_path):
    import edge_tts
    communicate = edge_tts.Communicate(text, voice="en-US-GuyNeural")
    word_events = []
    with open(out_path, "wb") as f:
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                f.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                # offset/duration come in 100-nanosecond units — convert to seconds
                word_events.append({
                    "text": chunk["text"],
                    "start": chunk["offset"] / 10_000_000,
                    "duration": chunk["duration"] / 10_000_000,
                })

    if not word_events:
        # Safety net: if the TTS engine didn't emit word-boundary timing this run,
        # fall back to evenly-spaced timing across the actual audio length so
        # captions still show instead of silently disappearing.
        print("  (No word-boundary timing from TTS — using evenly-spaced fallback.)")
        from moviepy.editor import AudioFileClip as _TmpAudio
        total = _TmpAudio(out_path).duration
        words = [w for w in text.split() if w.strip()]
        if words:
            per = total / len(words)
            word_events = [{"text": w, "start": i * per, "duration": per}
                            for i, w in enumerate(words)]

    return word_events


def generate_narration(text, out_path):
    return asyncio.run(_generate_narration_async(text, out_path))


# ---------------------------------------------------------------------------
# 4. Featured image (photo + title text overlay)
# ---------------------------------------------------------------------------

def make_featured_image(photo_path, title, out_path):
    from PIL import Image, ImageDraw, ImageFont, ImageFilter

    img = Image.open(photo_path).convert("RGB")
    img = img.resize((1200, 630))

    # Darken the bottom for text legibility
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    draw.rectangle([0, 380, 1200, 630], fill=(*BRAND_COLOR, 190))
    img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")

    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 52)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 28)
    except OSError:
        font = ImageFont.load_default()
        font_small = font

    # Simple word-wrap for the title
    words = title.split()
    lines, line = [], ""
    for w in words:
        test = (line + " " + w).strip()
        if draw.textlength(test, font=font) > 1080:
            lines.append(line)
            line = w
        else:
            line = test
    lines.append(line)

    y = 400
    for line in lines[:3]:
        draw.text((60, y), line, font=font, fill=(255, 255, 255))
        y += 62

    draw.text((60, y + 10), "EFerz — Nothing Impossible in IT World",
              font=font_small, fill=ACCENT_COLOR)

    img.save(out_path, quality=90)
    return out_path


# ---------------------------------------------------------------------------
# 5. Video assembly (vertical short, for YouTube Shorts / Reels)
# ---------------------------------------------------------------------------

def _render_caption_frame(context_words, highlight_idx, video_size=(1080, 1920)):
    """Renders one FULL-FRAME (1080x1920) transparent overlay with a few words near
    the bottom of the screen — the currently-spoken word is highlighted in red."""
    from PIL import Image, ImageDraw, ImageFont
    import numpy as np

    img = Image.new("RGBA", video_size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 46)
    except OSError:
        font = ImageFont.load_default()

    widths = [draw.textlength(w + " ", font=font) for w in context_words]
    total_w = sum(widths)
    x = (video_size[0] - total_w) / 2

    # Bottom-anchored: pill sits ~340px above the very bottom edge (safe zone,
    # clear of YouTube Shorts / Reels / TikTok's built-in UI buttons).
    pill_bottom = video_size[1] - 340
    pill_top = pill_bottom - 78
    y = pill_top + 14

    draw.rounded_rectangle(
        [max(0, x - 24), pill_top, min(video_size[0], x + total_w + 24), pill_bottom],
        radius=20, fill=(*BRAND_COLOR, 210),
    )

    for i, w in enumerate(context_words):
        color = CAPTION_HIGHLIGHT_COLOR if i == highlight_idx else (255, 255, 255)
        draw.text((x, y), w, font=font, fill=color)
        x += widths[i]

    return np.array(img)


def make_word_caption_clips(word_events, video_size=(1080, 1920)):
    """Builds one full-frame ImageClip per spoken word, each shown only for that
    word's duration — this is what creates the word-by-word highlight effect."""
    from moviepy.editor import ImageClip

    # edge-tts's reported WordBoundary offsets consistently land a bit AFTER the
    # word is actually heard (the highlight looked like it was trailing the voice),
    # so we nudge every timestamp earlier by this amount to resync them.
    SYNC_LEAD = 0.18

    window = 4  # how many words are visible on screen at once
    clips = []
    for i, w in enumerate(word_events):
        if not w["text"].strip():
            continue
        start_idx = max(0, i - window + 1)
        context = [e["text"] for e in word_events[start_idx:i + 1]]
        frame = _render_caption_frame(context, highlight_idx=len(context) - 1, video_size=video_size)

        rgb = frame[:, :, :3]
        alpha = frame[:, :, 3] / 255.0
        clip = ImageClip(rgb).set_mask(ImageClip(alpha, ismask=True))
        start_time = max(0.0, w["start"] - SYNC_LEAD)
        clip = clip.set_start(start_time).set_duration(max(w["duration"], 0.12))
        clips.append(clip)
    return clips


def make_outro_image(out_path, size=(1080, 1920)):
    from PIL import Image, ImageDraw, ImageFont

    WHITE = (255, 255, 255)
    RED = CAPTION_HIGHLIGHT_COLOR
    DARK = (30, 30, 30)

    img = Image.new("RGB", size, WHITE)
    draw = ImageDraw.Draw(img)

    # Red accent border frame
    border = 18
    draw.rectangle([0, 0, size[0], size[1]], outline=RED, width=border)

    try:
        font_big = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 82)
        font_mid = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 50)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 34)
    except OSError:
        font_big = font_mid = font_small = ImageFont.load_default()

    cy = size[1] // 2

    line = "EFerz"
    w = draw.textlength(line, font=font_big)
    draw.text(((size[0] - w) / 2, cy - 230), line, font=font_big, fill=RED)

    # Thin red divider line under the logo text
    draw.rectangle([(size[0] - 160) / 2, cy - 130, (size[0] + 160) / 2, cy - 122], fill=RED)

    tagline = "Nothing Impossible in IT World"
    w = draw.textlength(tagline, font=font_small)
    draw.text(((size[0] - w) / 2, cy - 90), tagline, font=font_small, fill=DARK)

    cta = "Visit eferz.com"
    w = draw.textlength(cta, font=font_mid)
    draw.rounded_rectangle(
        [(size[0] - w) / 2 - 44, cy + 30, (size[0] + w) / 2 + 44, cy + 122],
        radius=16, fill=RED,
    )
    draw.text(((size[0] - w) / 2, cy + 52), cta, font=font_mid, fill=WHITE)

    sub = "for a free strategy session"
    w = draw.textlength(sub, font=font_small)
    draw.text(((size[0] - w) / 2, cy + 160), sub, font=font_small, fill=(90, 90, 90))

    img.save(out_path)
    return out_path


def make_outro_clip(video_size=(1080, 1920)):
    """Builds the ~3-second branded closing slide with a short voice line."""
    from moviepy.editor import ImageClip, AudioFileClip

    outro_img_path = os.path.join(WORKDIR, "outro.png")
    make_outro_image(outro_img_path, video_size)

    outro_audio_path = os.path.join(WORKDIR, "outro_narration.mp3")
    generate_narration(
        "For more tips like this, visit EFerz dot com. Nothing impossible in IT world.",
        outro_audio_path,
    )
    audio = AudioFileClip(outro_audio_path)
    duration = max(audio.duration + 0.5, 3.0)
    clip = ImageClip(outro_img_path).set_duration(duration).set_audio(audio)
    return clip


def assemble_video(clip_paths, narration_path, word_events, out_path):
    from moviepy.editor import (VideoFileClip, AudioFileClip, ImageClip,
                                 CompositeVideoClip, concatenate_videoclips)

    narration = AudioFileClip(narration_path)
    target_duration = max(narration.duration - 0.05, 1.0)  # tiny safety margin

    if not clip_paths:
        die("No stock clips were downloaded — cannot assemble video.")

    from itertools import cycle
    loaded = {}
    segments, total = [], 0.0
    for path in cycle(clip_paths):
        if path not in loaded:
            c = VideoFileClip(path)
            c = c.resize(height=1920)
            if c.w < 1080:
                c = c.resize(width=1080)
            c = c.crop(x_center=c.w / 2, y_center=c.h / 2, width=1080, height=1920)
            loaded[path] = c
        c = loaded[path]
        remaining = target_duration - total
        if remaining <= 0:
            break
        piece = c.subclip(0, min(c.duration, remaining))
        segments.append(piece)
        total += piece.duration
        if len(segments) > 200:  # safety net against an infinite loop
            break

    video = concatenate_videoclips(segments, method="compose")
    video = video.subclip(0, target_duration).without_audio()

    caption_clips = make_word_caption_clips(word_events, video_size=(1080, 1920))

    main = CompositeVideoClip([video] + caption_clips).set_audio(
        narration.subclip(0, min(narration.duration, video.duration))
    )

    outro = make_outro_clip(video_size=(1080, 1920))

    # Smooth 0.6s dissolve from the main content into the outro, instead of a
    # hard cut — this is what makes it read as one continuous video.
    FADE = 0.6
    main = main.audio_fadeout(FADE)
    outro = outro.crossfadein(FADE).audio_fadein(FADE)
    final = concatenate_videoclips([main, outro], method="compose", padding=-FADE)

    final.write_videofile(out_path, fps=24, codec="libx264", audio_codec="aac",
                           threads=2, verbose=False, logger=None)
    return out_path


# ---------------------------------------------------------------------------
# 6. Publish to WordPress
# ---------------------------------------------------------------------------

def wp_session():
    s = requests.Session()
    s.auth = (WP_USERNAME, WP_APP_PASSWORD)
    s.headers.update(HTTP_HEADERS)
    return s


def wp_upload_media(session, file_path, mime_type, title):
    filename = os.path.basename(file_path)
    with open(file_path, "rb") as f:
        resp = session.post(
            f"{WP_BASE_URL}/wp-json/wp/v2/media",
            files={"file": (filename, f, mime_type)},
            timeout=180,
        )
    if resp.status_code not in (200, 201):
        die(f"Media upload failed ({filename}): {resp.status_code} {resp.text[:300]}")
    media = resp.json()
    session.post(f"{WP_BASE_URL}/wp-json/wp/v2/media/{media['id']}",
                 json={"alt_text": title, "title": title})
    return media["id"], media.get("source_url")


def wp_get_or_create_category(session, name):
    resp = session.get(f"{WP_BASE_URL}/wp-json/wp/v2/categories", params={"search": name})
    if resp.status_code == 200:
        for cat in resp.json():
            if cat["name"].lower() == name.lower():
                return cat["id"]
    resp = session.post(f"{WP_BASE_URL}/wp-json/wp/v2/categories", json={"name": name})
    if resp.status_code in (200, 201):
        return resp.json()["id"]
    print(f"  Could not resolve/create category '{name}': {resp.status_code} {resp.text[:150]}")
    return None


def wp_publish_post(session, article, featured_media_id, youtube_video_id, category_id):
    content = article["content_html"]
    if youtube_video_id:
        # A bare YouTube URL on its own line triggers WordPress's built-in oEmbed,
        # which automatically turns it into an embedded player - no <video> tag needed.
        content += (
            f'\n<!-- wp:embed {{"url":"https://www.youtube.com/watch?v={youtube_video_id}",'
            f'"type":"video","providerNameSlug":"youtube"}} -->\n'
            f'<figure class="wp-block-embed is-type-video">'
            f'<div class="wp-block-embed__wrapper">\n'
            f'https://www.youtube.com/watch?v={youtube_video_id}\n'
            f'</div></figure>\n<!-- /wp:embed -->\n'
        )

    payload = {
            "title": article["title"],
            "slug": article["slug"],
            "content": content,
            "status": "publish",
            "featured_media": featured_media_id,
            "meta": {
                "_yoast_wpseo_title": article["meta_title"],
                "_yoast_wpseo_metadesc": article["meta_description"],
                "_yoast_wpseo_metakeywords": article["meta_keywords"],
                "_yoast_wpseo_focuskw": article["focus_keyword"],
            },
        }
    if category_id:
        payload["categories"] = [category_id]

    resp = session.post(
        f"{WP_BASE_URL}/wp-json/wp/v2/posts",
        json=payload,
        timeout=60,
    )
    if resp.status_code not in (200, 201):
        die(f"Post publish failed: {resp.status_code} {resp.text[:400]}")
    return resp.json()


def log_topic(article):
    os.makedirs(os.path.dirname(TOPIC_LOG_PATH), exist_ok=True)
    is_new = not os.path.exists(TOPIC_LOG_PATH)
    with open(TOPIC_LOG_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if is_new:
            writer.writerow(["title", "slug", "focus_keyword"])
        writer.writerow([article["title"], article["slug"], article["focus_keyword"]])


# ---------------------------------------------------------------------------
# 7. Social media distribution (each is optional — skipped with a warning if
#    its credentials aren't set, so the pipeline never fails because of them)
# ---------------------------------------------------------------------------

HASHTAG_MAP = {
    "Web Design": ["#WebDesign", "#WebDevelopment", "#WordPress", "#WebsiteDesign"],
    "Digital Marketing": ["#DigitalMarketing", "#MarketingTips", "#SocialMediaMarketing", "#GrowthHacking"],
    "SEO": ["#SEO", "#SEOTips", "#GoogleRanking", "#SearchEngineOptimization"],
    "E-Commerce": ["#Ecommerce", "#OnlineStore", "#Shopify", "#EcommerceTips"],
    "Cybersecurity": ["#CyberSecurity", "#DataProtection", "#OnlineSafety", "#InfoSec"],
    "AI Tools": ["#AITools", "#ArtificialIntelligence", "#AI", "#TechTips"],
    "Branding": ["#Branding", "#BrandStrategy", "#SmallBusiness", "#BrandIdentity"],
    "Amazon FBA": ["#AmazonFBA", "#Ecommerce", "#OnlineBusiness", "#SideHustle"],
}
GENERIC_HASHTAGS = ["#TechTips", "#DigitalAgency", "#Shorts", "#EFerz", "#SmallBusinessTips"]


def build_hashtags(category):
    tags = HASHTAG_MAP.get(category, []) + GENERIC_HASHTAGS
    seen, out = set(), []
    for t in tags:
        if t.lower() not in seen:
            seen.add(t.lower())
            out.append(t)
    return out[:8]


def make_youtube_thumbnail(photo_path, title, out_path):
    """1280x720 thumbnail — bold, high-contrast, red accent border (attention-grabbing
    style similar to what performs well for Shorts/trending feeds)."""
    from PIL import Image, ImageDraw, ImageFont

    img = Image.open(photo_path).convert("RGB").resize((1280, 720))

    # Darken the whole frame slightly for text contrast, plus a bottom gradient band
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 90))
    img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
    band = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw_band = ImageDraw.Draw(band)
    draw_band.rectangle([0, 400, 1280, 720], fill=(*BRAND_COLOR, 220))
    img = Image.alpha_composite(img.convert("RGBA"), band).convert("RGB")

    # Red accent border — high-contrast "trending" framing
    draw = ImageDraw.Draw(img)
    border = 14
    draw.rectangle([0, 0, 1280, 720], outline=CAPTION_HIGHLIGHT_COLOR, width=border)

    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 72)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 36)
    except OSError:
        font = ImageFont.load_default()
        font_small = font

    words = title.split()
    lines, line = [], ""
    for w in words:
        test = (line + " " + w).strip()
        if draw.textlength(test, font=font) > 1120:
            lines.append(line)
            line = w
        else:
            line = test
    lines.append(line)
    lines = lines[:3]

    y = 420
    for line in lines:
        # Simple drop-shadow for legibility/pop
        draw.text((62, y + 2), line, font=font, fill=(0, 0, 0))
        draw.text((60, y), line, font=font, fill=(255, 255, 255))
        y += 82

    tag_text = "EFerz.com"
    draw.rounded_rectangle([60, y + 12, 60 + draw.textlength(tag_text, font=font_small) + 40, y + 68],
                            radius=10, fill=CAPTION_HIGHLIGHT_COLOR)
    draw.text((80, y + 20), tag_text, font=font_small, fill=(255, 255, 255))

    img.save(out_path, quality=92)
    return out_path


def post_to_youtube(video_path, thumbnail_path, article):
    client_id = os.environ.get("YOUTUBE_CLIENT_ID")
    client_secret = os.environ.get("YOUTUBE_CLIENT_SECRET")
    refresh_token = os.environ.get("YOUTUBE_REFRESH_TOKEN")
    if not (client_id and client_secret and refresh_token):
        print("  Skipping YouTube (YOUTUBE_CLIENT_ID/SECRET/REFRESH_TOKEN not set).")
        return None

    try:
        token_resp = requests.post("https://oauth2.googleapis.com/token", data={
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token",
        }, timeout=30)
        token_resp.raise_for_status()
        access_token = token_resp.json()["access_token"]

        hashtags = build_hashtags(article["category"])
        hashtag_line = " ".join(hashtags)
        # The first 3 hashtags in the description show above the title on YouTube.
        description = (
            f"{article['meta_description']}\n\n"
            f"Read the full article: {WP_BASE_URL}/{article['slug']}/\n\n"
            f"For more detail check our website: {WP_BASE_URL}\n\n{hashtag_line}"
        )
        snippet = {
            "title": f"{article['title']} #shorts"[:100],
            "description": description[:5000],
            "tags": list(dict.fromkeys(
                article["meta_keywords"].split(", ") + [h.lstrip("#") for h in hashtags]
            )),
            "categoryId": "28",  # Science & Technology
        }
        metadata = {"snippet": snippet, "status": {"privacyStatus": "public",
                                                     "selfDeclaredMadeForKids": False}}

        init_resp = requests.post(
            "https://www.googleapis.com/upload/youtube/v3/videos",
            params={"uploadType": "resumable", "part": "snippet,status"},
            headers={
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json; charset=UTF-8",
                "X-Upload-Content-Type": "video/mp4",
            },
            json=metadata,
            timeout=30,
        )
        init_resp.raise_for_status()
        upload_url = init_resp.headers["Location"]

        with open(video_path, "rb") as f:
            video_data = f.read()
        upload_resp = requests.put(
            upload_url,
            headers={"Content-Type": "video/mp4"},
            data=video_data,
            timeout=300,
        )
        upload_resp.raise_for_status()
        video_id = upload_resp.json().get("id")
        print(f"  YouTube: published -> https://youtube.com/shorts/{video_id}")

        # Custom thumbnail — this silently no-ops on non-phone-verified channels,
        # which is why it's wrapped separately and never fails the whole run.
        try:
            with open(thumbnail_path, "rb") as f:
                thumb_resp = requests.post(
                    "https://www.googleapis.com/upload/youtube/v3/thumbnails/set",
                    params={"videoId": video_id, "uploadType": "media"},
                    headers={"Authorization": f"Bearer {access_token}",
                             "Content-Type": "image/jpeg"},
                    data=f.read(),
                    timeout=60,
                )
            if thumb_resp.status_code not in (200, 201):
                print(f"  Custom thumbnail not set (channel may need phone verification "
                      f"for custom thumbnails): {thumb_resp.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"  Thumbnail upload failed (video still published fine): {e}")

        return video_id
    except requests.exceptions.RequestException as e:
        print(f"  YouTube upload failed (continuing): {e}")
        return None


def post_to_facebook(video_path, article):
    """Publishes as an actual Facebook Reel (not a regular Page video) using the
    dedicated Video Reels API: start -> upload -> finish/publish."""
    page_id = os.environ.get("FB_PAGE_ID")
    page_token = os.environ.get("FB_PAGE_ACCESS_TOKEN")
    if not (page_id and page_token):
        print("  Skipping Facebook (FB_PAGE_ID/FB_PAGE_ACCESS_TOKEN not set).")
        return

    try:
        # Step 1: start an upload session
        start_resp = requests.post(
            f"https://graph.facebook.com/v21.0/{page_id}/video_reels",
            params={"upload_phase": "start", "access_token": page_token},
            timeout=30,
        )
        start_resp.raise_for_status()
        start_data = start_resp.json()
        video_id = start_data["video_id"]
        upload_url = start_data["upload_url"]

        # Step 2: upload the raw video bytes to the given upload session URL
        with open(video_path, "rb") as f:
            video_bytes = f.read()
        upload_resp = requests.post(
            upload_url,
            headers={
                "Authorization": f"OAuth {page_token}",
                "offset": "0",
                "file_size": str(len(video_bytes)),
            },
            data=video_bytes,
            timeout=300,
        )
        upload_resp.raise_for_status()

        # Step 3: finish the session and publish as a Reel
        caption = f"{article['title']}\n\n{article['meta_description']}"
        finish_resp = requests.post(
            f"https://graph.facebook.com/v21.0/{page_id}/video_reels",
            params={
                "upload_phase": "finish",
                "video_id": video_id,
                "video_state": "PUBLISHED",
                "description": caption,
                "access_token": page_token,
            },
            timeout=60,
        )
        finish_resp.raise_for_status()
        print(f"  Facebook: Reel published -> video id {video_id}")
    except requests.exceptions.RequestException as e:
        body = e.response.text[:500] if getattr(e, "response", None) is not None else ""
        print(f"  Facebook Reel upload failed (continuing): {e}\n  Response body: {body}")


def post_to_instagram(video_url, article):
    ig_user_id = os.environ.get("IG_BUSINESS_ACCOUNT_ID")
    page_token = os.environ.get("FB_PAGE_ACCESS_TOKEN")  # same token as Facebook Page
    if not (ig_user_id and page_token):
        print("  Skipping Instagram (IG_BUSINESS_ACCOUNT_ID/FB_PAGE_ACCESS_TOKEN not set).")
        return
    if not video_url:
        print("  Skipping Instagram (no public video URL available).")
        return

    try:
        caption = f"{article['title']}\n\n{article['meta_description']}\n\n#EFerz #TechTips"
        create_resp = requests.post(
            f"https://graph.facebook.com/v21.0/{ig_user_id}/media",
            params={
                "media_type": "REELS",
                "video_url": video_url,
                "caption": caption,
                "access_token": page_token,
            },
            timeout=60,
        )
        create_resp.raise_for_status()
        container_id = create_resp.json()["id"]

        import time
        for _ in range(20):  # poll up to ~2 minutes while Instagram processes the video
            status_resp = requests.get(
                f"https://graph.facebook.com/v21.0/{container_id}",
                params={"fields": "status_code", "access_token": page_token},
                timeout=30,
            )
            status = status_resp.json().get("status_code")
            if status == "FINISHED":
                break
            if status == "ERROR":
                print("  Instagram: media processing failed.")
                return
            time.sleep(6)

        publish_resp = requests.post(
            f"https://graph.facebook.com/v21.0/{ig_user_id}/media_publish",
            params={"creation_id": container_id, "access_token": page_token},
            timeout=30,
        )
        publish_resp.raise_for_status()
        print(f"  Instagram: published -> media id {publish_resp.json().get('id')}")
    except requests.exceptions.RequestException as e:
        body = e.response.text[:500] if getattr(e, "response", None) is not None else ""
        print(f"  Instagram publish failed (continuing): {e}\n  Response body: {body}")


# ---------------------------------------------------------------------------

def main():
    check_env()
    os.makedirs(WORKDIR, exist_ok=True)

    print("1/6 Generating article with Gemini...")
    article = generate_article()
    print(f"   Topic: {article['title']}")

    print("2/6 Downloading Pexels stock clips...")
    clips_dir = os.path.join(WORKDIR, "clips")
    clip_paths = fetch_pexels_clips(article["pexels_search_terms"], clips_dir)
    if not clip_paths:
        die("No Pexels clips could be downloaded for this topic's search terms.")

    print("3/6 Generating narration audio (with word timings)...")
    narration_path = os.path.join(WORKDIR, "narration.mp3")
    word_events = generate_narration(article["narration_script"], narration_path)
    print(f"   Captured {len(word_events)} word-timing events for captions.")

    print("4/6 Building featured image + thumbnail...")
    photo_path = os.path.join(WORKDIR, "featured_source.jpg")
    fetch_pexels_photo(article["pexels_search_terms"][0], photo_path)
    image_path = os.path.join(WORKDIR, "featured.jpg")
    make_featured_image(photo_path, article["title"], image_path)
    thumbnail_path = os.path.join(WORKDIR, "thumbnail.jpg")
    make_youtube_thumbnail(photo_path, article["title"], thumbnail_path)

    print("5/6 Assembling short video (this can take a few minutes)...")
    video_path = os.path.join(WORKDIR, "short.mp4")
    assemble_video(clip_paths, narration_path, word_events, video_path)

    print("6/7 Uploading video to YouTube...")
    youtube_video_id = post_to_youtube(video_path, thumbnail_path, article)

    print("7/7 Publishing to WordPress...")
    session = wp_session()
    image_id, _ = wp_upload_media(session, image_path, "image/jpeg", article["title"])

    article["content_html"] = insert_inline_images(
        session, article["content_html"], article["pexels_search_terms"], article, WORKDIR
    )
    article["content_html"] = append_cta(article["content_html"], article)

    # Only upload the video file to WP media if Instagram is actually configured —
    # it's the only consumer of this URL, and video uploads currently trigger a
    # server-side ModSecurity block that still needs a hosting-side fix (see README).
    video_file_url = None
    if os.environ.get("IG_BUSINESS_ACCOUNT_ID"):
        try:
            _, video_file_url = wp_upload_media(session, video_path, "video/mp4", article["title"])
        except SystemExit:
            print("  Video upload for Instagram failed — continuing without it.")
    category_id = wp_get_or_create_category(session, article["category"])
    post = wp_publish_post(session, article, image_id, youtube_video_id, category_id)
    log_topic(article)

    print(f"\nDone. Published: {post.get('link', post.get('id'))}")

    print("\nPosting to remaining social platforms...")
    post_to_facebook(video_path, article)
    post_to_instagram(video_file_url, article)


if __name__ == "__main__":
    main()
