#!/usr/bin/env python3
"""
update_image_alt.py

Reads seo-data/image-alt.csv (produced/filled after list_missing_alt.py) and pushes
each row's "alt_text" to the matching WordPress media item via the REST API.
Native WP field — no extra plugin/meta registration needed.
"""

import csv
import os
import sys
import requests

WP_BASE_URL = os.environ.get("WP_BASE_URL", "").rstrip("/")
WP_USERNAME = os.environ.get("WP_USERNAME", "")
WP_APP_PASSWORD = os.environ.get("WP_APP_PASSWORD", "")
CSV_PATH = os.environ.get("IMAGE_ALT_CSV_PATH", "seo-data/image-alt.csv")

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Accept": "application/json",
}


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def main():
    if not (WP_BASE_URL and WP_USERNAME and WP_APP_PASSWORD):
        die("WP_BASE_URL, WP_USERNAME, and WP_APP_PASSWORD environment variables are required.")
    if not os.path.exists(CSV_PATH):
        die(f"CSV file not found at {CSV_PATH}. Run list_missing_alt.py first.")

    session = requests.Session()
    session.auth = (WP_USERNAME, WP_APP_PASSWORD)
    session.headers.update(HEADERS)

    updated, skipped, failed = 0, 0, 0

    with open(CSV_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            media_id = (row.get("media_id") or "").strip()
            alt_text = (row.get("alt_text") or "").strip()

            if not media_id:
                continue
            if not alt_text:
                skipped += 1
                continue

            resp = session.post(
                f"{WP_BASE_URL}/wp-json/wp/v2/media/{media_id}",
                json={"alt_text": alt_text},
            )
            if resp.status_code in (200, 201):
                print(f"OK: media {media_id} -> '{alt_text}'")
                updated += 1
            else:
                print(f"FAIL: media {media_id} -> HTTP {resp.status_code} {resp.text[:200]}")
                failed += 1

    print(f"\nDone. Updated: {updated}, Skipped (blank): {skipped}, Failed: {failed}")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
