# EFerz SEO Automation (GitHub → WordPress)

Layout/design 100% same rehta hai — ye automation sirf SEO cheezein update karti hai:
Meta Title, Meta Description, Meta Keywords, Focus Keyword, Schema Markup, aur Image ALT text.

## Files kya karti hain

| File | Kaam |
|---|---|
| `wp-mu-plugin/expose-seo-meta-rest.php` | Yoast/RankMath meta fields ko REST API se editable banata hai |
| `wp-mu-plugin/eferz-schema-markup.php` | Organization + LocalBusiness schema (JSON-LD) site-wide inject karta hai |
| `update_seo_meta.py` + `seo-data/pages.csv` | Har page ka Title/Description/Keywords/Focus-Keyword update karta hai |
| `list_missing_alt.py` | Saari images list karta hai jinka ALT text missing hai |
| `update_image_alt.py` + `seo-data/image-alt.csv` | ALT text images par push karta hai |

## Setup (already done — recap)

1. `wp-mu-plugin/expose-seo-meta-rest.php` aur `wp-mu-plugin/eferz-schema-markup.php`
   dono files `/wp-content/mu-plugins/` mein daalein.
2. GitHub Secrets mein `WP_BASE_URL`, `WP_USERNAME`, `WP_APP_PASSWORD` already set hain.

## Roz-marra istemal

### Meta Title/Description/Keyword/Focus-Keyword update karna
`seo-data/pages.csv` edit karein → commit karein → GitHub Actions apne aap chal jayega.

### Image ALT text add karna (naya step)
1. GitHub repo → **Actions** tab → **"List Images Missing ALT Text"** workflow select karein
   → **"Run workflow"** button dabayein.
2. 1-2 minute baad `seo-data/image-alt.csv` file repo mein khud commit ho jayegi, jisme
   har image ka `source_url` (link jahan image dekh sakte hain) hoga.
3. Har row ka `source_url` khol kar dekhein image kya hai, phir `alt_text` column mein
   1-2 line ka simple description likhein (e.g. "EFerz team working on client website design").
4. File commit karein — **"Update Image ALT Text"** workflow apne aap chal kar sab push kar dega.

   *(Tip: agar images ka content pata na chale ya likhne mein madad chahiye ho, screenshot
   yahan chat mein bhej dein — main dekh kar accurate ALT text likh dunga.)*

## Schema Markup

`eferz-schema-markup.php` already Organization + LocalBusiness info (USA + KSA offices, phone,
email, social links) Google ko de raha hai. Business info change ho (naya address/phone) to
is file mein directly update kar dein.

## Ye automation KYA NAHI karti (manual/ongoing kaam)

- **Blog/content likhna** — organic ranking ke liye naya content zaroori hai, lekin filhaal
  site par blog section hi nahi hai.
- **Backlinks banana** — dusri websites se link milna (Google Business Profile, directories,
  partnerships) — ye automation se nahi hota.
- **Page speed optimization** — images compress karna, caching plugin lagana.
- Ye sab agle steps hain jab pehla phase (meta + schema + alt text) stable ho jaye.
