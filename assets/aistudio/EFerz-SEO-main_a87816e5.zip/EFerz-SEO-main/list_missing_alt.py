#!/usr/bin/env python3
"""
list_missing_alt.py

Scans the WordPress media library and writes a CSV of every image that has
no ALT text yet, to seo-data/image-alt.csv. Fill in the "alt_text" column
for each row, commit, then run update_image_alt.py to push them.

Uses the same WP_BASE_URL / WP_USERNAME / WP_APP_PASSWORD as the meta script.
"""

import csv
import os
import sys
import requests

WP_BASE_URL = os.environ.get("WP_BASE_URL", "").rstrip("/")
WP_USERNAME = os.environ.get("WP_USERNAME", "")
WP_APP_PASSWORD = os.environ.get("WP_APP_PASSWORD", "")
OUT_PATH = os.environ.get("IMAGE_ALT_CSV_PATH", "seo-data/image-alt.csv")

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Accept": "application/json",
}


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def main():
    if not (WP_BASE_URL and WP_USERNAME and WP_APP_PASSWORD):
        die("WP_BASE_URL, WP_USERNAME, and WP_APP_PASSWORD environment variables are required.")

    session = requests.Session()
    session.auth = (WP_USERNAME, WP_APP_PASSWORD)
    session.headers.update(HEADERS)

    rows = []
    page = 1
    while True:
        resp = session.get(
            f"{WP_BASE_URL}/wp-json/wp/v2/media",
            params={"per_page": 100, "page": page, "media_type": "image"},
        )
        if resp.status_code != 200:
            if page == 1:
                die(f"Could not list media: HTTP {resp.status_code} {resp.text[:300]}")
            break
        items = resp.json()
        if not items:
            break
        for item in items:
            alt = (item.get("alt_text") or "").strip()
            if not alt:
                rows.append({
                    "media_id": item["id"],
                    "filename": item.get("source_url", "").split("/")[-1],
                    "used_on_page": item.get("post", "") or "",
                    "source_url": item.get("source_url", ""),
                    "alt_text": "",
                })
        page += 1

    os.makedirs(os.path.dirname(OUT_PATH) or ".", exist_ok=True)
    with open(OUT_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f, fieldnames=["media_id", "filename", "used_on_page", "source_url", "alt_text"]
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"Found {len(rows)} images with no ALT text. Written to {OUT_PATH}")
    print("Open each 'source_url' to see the image, fill in 'alt_text', commit, "
          "then run update_image_alt.py.")


if __name__ == "__main__":
    main()
