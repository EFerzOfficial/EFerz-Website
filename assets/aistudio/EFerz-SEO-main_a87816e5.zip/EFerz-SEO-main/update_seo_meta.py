#!/usr/bin/env python3
"""
update_seo_meta.py

Reads seo-data/pages.csv and pushes Meta Title / Meta Description / Meta Keywords
to WordPress pages/posts via the REST API, using WordPress "Application Passwords"
(built into WP 5.6+, no extra plugin needed for auth).

It ONLY touches SEO meta fields — it never touches page content, Elementor layout,
or design in any way.

REQUIRED ENVIRONMENT VARIABLES (set as GitHub Secrets, never hard-code these):
  WP_BASE_URL   e.g. https://eferz.com
  WP_USERNAME   the WordPress admin/editor username
  WP_APP_PASSWORD   an Application Password generated in WP Admin > Users > Profile

CSV COLUMNS (seo-data/pages.csv):
  page_id       WordPress numeric post/page ID (leave blank if using page_slug)
  page_slug     URL slug, e.g. "about-us" (used to look up the ID if page_id is blank)
  meta_title
  meta_description
  meta_keywords
  seo_plugin    "yoast" or "rankmath" — tells the script which meta field names to use
"""

import csv
import os
import sys
import requests

WP_BASE_URL = os.environ.get("WP_BASE_URL", "").rstrip("/")
WP_USERNAME = os.environ.get("WP_USERNAME", "")
WP_APP_PASSWORD = os.environ.get("WP_APP_PASSWORD", "")
CSV_PATH = os.environ.get("SEO_CSV_PATH", "seo-data/pages.csv")

FIELD_MAP = {
    "yoast": {
        "title": "_yoast_wpseo_title",
        "description": "_yoast_wpseo_metadesc",
        "keywords": "_yoast_wpseo_metakeywords",
        "focus_keyword": "_yoast_wpseo_focuskw",
    },
    "rankmath": {
        "title": "rank_math_title",
        "description": "rank_math_description",
        "keywords": "rank_math_focus_keyword",
        "focus_keyword": "rank_math_focus_keyword",
    },
}

# Post types to search when only a slug is given, tried in this order.
POST_TYPES_FOR_LOOKUP = ["pages", "posts", "project"]


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def check_auth(session):
    """Verify the base URL and credentials work before doing anything else."""
    url = f"{WP_BASE_URL}/wp-json/wp/v2/users/me"
    try:
        resp = session.get(url, timeout=15)
    except requests.exceptions.RequestException as e:
        die(f"Could not reach {url} -> {e}")

    if resp.status_code == 401:
        die(f"Authentication failed (401) at {url}. Check WP_USERNAME and "
            f"WP_APP_PASSWORD secrets — the app password must be copied exactly "
            f"as shown (spaces included) with no extra characters.\nResponse: {resp.text[:300]}")
    if resp.status_code == 403:
        die(f"Blocked (403) at {url}. A security plugin/firewall (e.g. Wordfence) "
            f"may be blocking REST API requests from GitHub's servers.\nResponse: {resp.text[:300]}")
    if resp.status_code == 404:
        die(f"404 at {url}. Check WP_BASE_URL is correct (e.g. https://eferz.com, "
            f"no trailing slash) and that the REST API isn't disabled.\nResponse: {resp.text[:300]}")
    if resp.status_code != 200:
        die(f"Unexpected status {resp.status_code} at {url}\nResponse: {resp.text[:300]}")

    print(f"Auth OK — logged in as: {resp.json().get('name', 'unknown')}")


def find_id_by_slug(session, slug):
    # Try the custom bypass endpoint first — handles post types (like "project") that
    # some themes hide from the standard /wp/v2/<type> list endpoints.
    resp = session.get(f"{WP_BASE_URL}/wp-json/eferz-seo/v1/resolve",
                        params={"slug": slug, "post_type": "any"})
    if resp.status_code == 200:
        data = resp.json()
        return data["id"], data["post_type"]

    for post_type in POST_TYPES_FOR_LOOKUP:
        url = f"{WP_BASE_URL}/wp-json/wp/v2/{post_type}"
        resp = session.get(url, params={"slug": slug})
        if resp.status_code == 200:
            if resp.json():
                item = resp.json()[0]
                return item["id"], post_type
        else:
            print(f"  ({post_type} lookup for '{slug}' -> HTTP {resp.status_code}: {resp.text[:150]})")
    return None, None


def update_meta_via_bypass(session, post_id, meta):
    url = f"{WP_BASE_URL}/wp-json/eferz-seo/v1/update-meta/{post_id}"
    return session.post(url, json={"meta": meta})


def update_meta(session, post_type, post_id, meta):
    # Try the bypass endpoint first (works regardless of theme/plugin REST filtering).
    resp = update_meta_via_bypass(session, post_id, meta)
    if resp.status_code in (200, 201):
        return resp
    # Fall back to the standard REST endpoint.
    url = f"{WP_BASE_URL}/wp-json/wp/v2/{post_type}/{post_id}"
    return session.post(url, json={"meta": meta})


def main():
    if not (WP_BASE_URL and WP_USERNAME and WP_APP_PASSWORD):
        die("WP_BASE_URL, WP_USERNAME, and WP_APP_PASSWORD environment variables are required.")

    session = requests.Session()
    session.auth = (WP_USERNAME, WP_APP_PASSWORD)
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        "Accept": "application/json",
    })
    check_auth(session)

    if not os.path.exists(CSV_PATH):
        die(f"CSV file not found at {CSV_PATH}")

    updated, skipped, failed = 0, 0, 0

    with open(CSV_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            slug = (row.get("page_slug") or "").strip()
            page_id = (row.get("page_id") or "").strip()
            plugin = (row.get("seo_plugin") or "yoast").strip().lower()

            if plugin not in FIELD_MAP:
                print(f"SKIP: unknown seo_plugin '{plugin}' for row {row}")
                skipped += 1
                continue

            fields = FIELD_MAP[plugin]
            meta = {}
            if row.get("meta_title", "").strip():
                meta[fields["title"]] = row["meta_title"].strip()
            if row.get("meta_description", "").strip():
                meta[fields["description"]] = row["meta_description"].strip()
            if row.get("meta_keywords", "").strip():
                meta[fields["keywords"]] = row["meta_keywords"].strip()
            if row.get("focus_keyword", "").strip():
                meta[fields["focus_keyword"]] = row["focus_keyword"].strip()

            if not meta:
                print(f"SKIP: no meta values provided for slug='{slug}' id='{page_id}'")
                skipped += 1
                continue

            post_type = "pages"
            if page_id:
                resolved_id = page_id
            elif slug:
                resolved_id, resolved_type = find_id_by_slug(session, slug)
                if resolved_id is None:
                    print(f"FAIL: could not find a page/post with slug '{slug}'")
                    failed += 1
                    continue
                post_type = resolved_type
            else:
                print(f"SKIP: row has neither page_id nor page_slug: {row}")
                skipped += 1
                continue

            resp = update_meta(session, post_type, resolved_id, meta)
            if resp.status_code in (200, 201):
                print(f"OK: updated {post_type} id={resolved_id} slug='{slug}'")
                updated += 1
            else:
                print(f"FAIL: {post_type} id={resolved_id} slug='{slug}' -> "
                      f"{resp.status_code} {resp.text}")
                failed += 1

    print(f"\nDone. Updated: {updated}, Skipped: {skipped}, Failed: {failed}")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
