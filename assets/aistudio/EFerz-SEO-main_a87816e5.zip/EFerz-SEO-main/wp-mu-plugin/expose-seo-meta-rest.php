<?php
/**
 * Plugin Name: Expose SEO Meta to REST API
 * Description: Allows Meta Title, Meta Description, and Meta Keywords (Yoast SEO or Rank Math)
 *              to be read/written via the WordPress REST API, so external tools (like a GitHub
 *              Actions script) can update them without touching page layout/content.
 * Author: EFerz SEO Automation
 *
 * INSTALL: Upload this file to /wp-content/mu-plugins/ (create that folder if it doesn't exist).
 * "mu-plugins" = Must Use plugins, they load automatically, no activation needed.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'init', function () {

    // Post types this should apply to. Add 'post' or custom types (e.g. 'project') if needed.
    $post_types = array( 'page', 'post', 'project' );

    foreach ( $post_types as $post_type ) {

        // ---- Yoast SEO fields ----
        register_post_meta( $post_type, '_yoast_wpseo_title', array(
            'show_in_rest' => true,
            'single'       => true,
            'type'         => 'string',
            'auth_callback' => function () {
                return current_user_can( 'edit_posts' );
            },
        ) );

        register_post_meta( $post_type, '_yoast_wpseo_metadesc', array(
            'show_in_rest' => true,
            'single'       => true,
            'type'         => 'string',
            'auth_callback' => function () {
                return current_user_can( 'edit_posts' );
            },
        ) );

        register_post_meta( $post_type, '_yoast_wpseo_metakeywords', array(
            'show_in_rest' => true,
            'single'       => true,
            'type'         => 'string',
            'auth_callback' => function () {
                return current_user_can( 'edit_posts' );
            },
        ) );

        // ---- Rank Math fields (use these instead if Rank Math is the active SEO plugin) ----
        register_post_meta( $post_type, 'rank_math_title', array(
            'show_in_rest' => true,
            'single'       => true,
            'type'         => 'string',
            'auth_callback' => function () {
                return current_user_can( 'edit_posts' );
            },
        ) );

        register_post_meta( $post_type, 'rank_math_description', array(
            'show_in_rest' => true,
            'single'       => true,
            'type'         => 'string',
            'auth_callback' => function () {
                return current_user_can( 'edit_posts' );
            },
        ) );

        register_post_meta( $post_type, 'rank_math_focus_keyword', array(
            'show_in_rest' => true,
            'single'       => true,
            'type'         => 'string',
            'auth_callback' => function () {
                return current_user_can( 'edit_posts' );
            },
        ) );
    }
} );
